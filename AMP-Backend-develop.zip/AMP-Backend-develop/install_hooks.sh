#!/bin/sh

# Define the marker file
MARKER_FILE=".git/hooks/hooks_installed"

# Check if the marker file exists
if [ -f "$MARKER_FILE" ]; then
	echo "Git hooks are already installed."
	exit 0
fi

# Create the .git/hooks directory if it doesn't exist
mkdir -p .git/hooks

# Create the pre-commit hook
cat <<'EOF' >.git/hooks/pre-commit
#!/bin/sh

# Prevent use of console print logs
if git diff --cached --name-only --diff-filter=ACM | grep -E '\.(java)$' | xargs grep -n -H 'System\.out\.println\|System\.err\.println'; then
  echo "Console print logs (System.out.println or System.err.println) are not allowed."
  exit 1
fi

# Run Checkstyle
mvn checkstyle:check
 if [ $? -ne 0 ]; then
  echo "Checkstyle checks failed. Please fix the issues before committing."
  exit 1
fi


# Allow only documentation comments
if git diff --cached --name-only --diff-filter=ACM | grep -E '\.(java)$' | xargs grep -n -H '^//'; then
  echo "Only documentation comments (/** ... */) are allowed. Inline comments (//) are not permitted."
  exit 1
fi

echo "All checks passed. Proceeding with commit."
EOF

# Create the pre-push hook
cat <<'EOF' >.git/hooks/pre-push
#!/bin/bash

# Run the build
mvn clean install

# Check if the build was successful
if [ $? -ne 0 ]; then
  echo "Build failed. Aborting push."
  exit 1
fi

echo "Build succeeded. Proceeding with push."
EOF

# Make the hooks executable
chmod +x .git/hooks/pre-commit
chmod +x .git/hooks/pre-push

# Create the marker file
touch "$MARKER_FILE"

echo "Git hooks installed successfully."
