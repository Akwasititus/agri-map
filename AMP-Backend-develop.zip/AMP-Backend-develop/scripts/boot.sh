cd /home/projects/agriculture-marketplace-backend/ &&
	docker compose -f docker-compose.yml up --remove-orphans -d
