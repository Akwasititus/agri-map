docker volume prune --force && docker system prune -f
