aws ecr get-login-password --region eu-west-1 | docker login --username AWS --password-stdin 909544387219.dkr.ecr.eu-west-1.amazonaws.com
