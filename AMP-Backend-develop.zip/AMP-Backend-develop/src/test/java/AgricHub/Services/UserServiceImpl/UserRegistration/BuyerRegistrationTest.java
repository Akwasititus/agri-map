package AgricHub.Services.UserServiceImpl.UserRegistration;

import AgricHub.DTOs.BuyerDTOs.BuyerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.EmailSendingException;
import AgricHub.Exception.UserAlreadyExist;
import AgricHub.Models.User;
import AgricHub.Repositories.UserRepository;
import AgricHub.Email.EmailTokenService;
import AgricHub.Services.UserServiceImpl.BuyerAuthServiceImpl;
import jakarta.mail.MessagingException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.SIGN_UP_SUCCESS;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.USER_ALREADY_EXIST;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class
BuyerRegistrationTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private EmailTokenService emailTokenService;

    @InjectMocks
    private BuyerAuthServiceImpl buyerAuthService;

    private BuyerRegistrationDto buyerRegistrationDto;

    @BeforeEach
    void setUp() {
        buyerRegistrationDto = BuyerRegistrationDto.builder()
                .email("buyer@example.com")
                .password("password123")
                .firstName("John")
                .lastName("Doe")
                .phone("1234567890")
                .city("Tepa")
                .country("Ghana")
                .region("Ashanti")
                .build();
    }

    @Test
    void registerBuyer_Success() throws MessagingException {
        // Arrange
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(new User());
        doNothing().when(emailTokenService).sendValidationEmail(any(User.class));

        // Act
        GenResponse response = buyerAuthService.registerBuyer(buyerRegistrationDto);

        // Assert
        assertThat(response.getStatus()).isEqualTo(HttpStatus.CREATED.value());
        assertThat(response.getMessage()).isEqualTo(SIGN_UP_SUCCESS);

        verify(userRepository).findByEmail(buyerRegistrationDto.getEmail().trim());
        verify(passwordEncoder).encode(buyerRegistrationDto.getPassword());
        verify(userRepository).save(any(User.class));
        verify(emailTokenService).sendValidationEmail(any(User.class));
    }

    @Test
    void registerBuyer_UserAlreadyExists() {
        // Arrange
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.of(new User()));

        // Act & Assert
        assertThatThrownBy(() -> buyerAuthService.registerBuyer(buyerRegistrationDto))
                .isInstanceOf(UserAlreadyExist.class)
                .hasMessage(USER_ALREADY_EXIST);

        verify(userRepository).findByEmail(buyerRegistrationDto.getEmail().trim());
        verifyNoMoreInteractions(passwordEncoder, emailTokenService);
    }

    @Test
    void registerBuyer_EmailSendingFails() throws MessagingException {
        // Arrange
        when(userRepository.findByEmail(anyString())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(new User());
        doThrow(new MessagingException("Email sending failed")).when(emailTokenService).sendValidationEmail(any(User.class));

        // Act & Assert
        assertThatThrownBy(() -> buyerAuthService.registerBuyer(buyerRegistrationDto))
                .isInstanceOf(EmailSendingException.class)
                .hasMessage("Error sending validation email");

        verify(userRepository).findByEmail(buyerRegistrationDto.getEmail().trim());
        verify(passwordEncoder).encode(buyerRegistrationDto.getPassword());
        verify(userRepository).save(any(User.class));
        verify(emailTokenService).sendValidationEmail(any(User.class));
    }
}