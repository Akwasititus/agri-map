package AgricHub.Services.UserServiceImpl.CartService;

import AgricHub.DTOs.ResponseDTOs.CartProductsResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.NotFoundException;
import AgricHub.Exception.UserAlreadyExist;
import AgricHub.Models.Dashbord.Cart;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.User;
import AgricHub.Repositories.CartRepository;
import AgricHub.Repositories.ProductRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserServiceImpl.CartServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
        import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CartServiceTest {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private CartServiceImpl cartService;

    private UUID userId;
    private UUID productId;
    private User user;
    private Product product;
    private Cart cart;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        productId = UUID.randomUUID();

        user = new User();
        user.setId(userId);
        user.setEmail("test@example.com");

        product = new Product();
        product.setId(productId);
        product.setName("Test Product");
        product.setAmount(10.0);

        cart = new Cart();
        cart.setProducts(new ArrayList<>());
        user.setCart(cart);
    }

    @Test
    void addProductToCart_Success() {
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(productRepository.findById(productId)).thenReturn(Optional.of(product));
        when(userRepository.save(any(User.class))).thenReturn(user);

        GenResponse response = cartService.addProductToCart(userId, productId);

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
        assertEquals("Product added to cart", response.getMessage());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void addProductToCart_ProductAlreadyInCart() {
        cart.getProducts().add(product);
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(productRepository.findById(productId)).thenReturn(Optional.of(product));

        assertThrows(UserAlreadyExist.class, () -> cartService.addProductToCart(userId, productId));
    }

    @Test
    void removeProductFromCart_Success() {
        cart.getProducts().add(product);
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);

        GenResponse response = cartService.removeProductFromCart(userId, productId);

        assertEquals(HttpStatus.OK.value(), response.getStatus());
        assertEquals("Product removed from cart", response.getMessage());
        assertTrue(cart.getProducts().isEmpty());
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void removeProductFromCart_ProductNotInCart() {
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));

        assertThrows(NotFoundException.class, () -> cartService.removeProductFromCart(userId, productId));
    }

    @Test
    void getCartProducts_Success() {
        cart.getProducts().add(product);
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));

        CartProductsResponse response = cartService.getCartProducts(userId);

        assertNotNull(response);
        assertEquals(1, response.getProducts().size());
        assertEquals(user.getEmail(), response.getUserEmail());
    }


    @Test
    void clearCart_Success() {
        cart.getProducts().add(product);
        when(userRepository.findById(userId)).thenReturn(Optional.of(user));
        when(cartRepository.save(any(Cart.class))).thenReturn(cart);

        GenResponse response = cartService.clearCart(userId);

        assertEquals(HttpStatus.OK.value(), response.getStatus());
        assertEquals("Cart cleared successfully", response.getMessage());
        assertTrue(cart.getProducts().isEmpty());
        verify(cartRepository, times(1)).save(cart);
    }
}