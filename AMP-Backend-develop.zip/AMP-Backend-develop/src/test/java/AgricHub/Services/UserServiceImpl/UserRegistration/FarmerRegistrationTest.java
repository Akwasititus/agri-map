package AgricHub.Services.UserServiceImpl.UserRegistration;

import AgricHub.DTOs.FarmerDTOs.FarmerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.EmailSendingException;
import AgricHub.Exception.UserAlreadyExist;
import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import AgricHub.Models.Roles.RoleEnum;
import AgricHub.Models.User;
import AgricHub.Repositories.FarmerBusinessProfileRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Email.EmailTokenService;
import AgricHub.Services.UserServiceImpl.FarmerAuthServicesImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;

import jakarta.mail.MessagingException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.SIGN_UP_SUCCESS;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.USER_ALREADY_EXIST;

@ExtendWith(MockitoExtension.class)
class FarmerAuthServicesImplTest {

	@InjectMocks
	private FarmerAuthServicesImpl farmerAuthServices;

	@Mock
	private UserRepository userRepository;

	@Mock
	private PasswordEncoder passwordEncoder;

	@Mock
	private EmailTokenService emailTokenService;

	@Mock
	private FarmerBusinessProfileRepository farmerBusinessProfileRepository;



	@Test
	void registerFarmer_UserAlreadyExists() throws MessagingException {
		// Arrange
		FarmerRegistrationDto dto = createFarmerRegistrationDto();

		when(userRepository.findByEmail(dto.getEmail().trim())).thenReturn(Optional.of(new User()));

		// Act & Assert
		assertThrows(UserAlreadyExist.class, () -> farmerAuthServices.registerFarmer(dto));

		verify(farmerBusinessProfileRepository, never()).save(any());
		verify(userRepository, never()).save(any());
		verify(emailTokenService, never()).sendValidationEmail(any());
	}



	private FarmerRegistrationDto createFarmerRegistrationDto() {
		FarmerRegistrationDto dto = new FarmerRegistrationDto();
		dto.setEmail("farmer@example.com");
		dto.setPassword("password123");
		dto.setFirstName("John");
		dto.setLastName("Doe");
		dto.setPhone("1234567890");
		dto.setProfileImage("profile.jpg");
		return dto;
	}


}