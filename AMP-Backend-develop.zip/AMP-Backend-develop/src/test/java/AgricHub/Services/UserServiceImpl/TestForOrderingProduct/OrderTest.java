package AgricHub.Services.UserServiceImpl.TestForOrderingProduct;

import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.Dashbord.*;
import AgricHub.Models.User;
import AgricHub.Repositories.OrderProductRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.CartService;
import AgricHub.Services.UserServiceImpl.BuyerDashBordServiceIMPL;
import AgricHub.Services.UserServiceImpl.SocketService.NotificationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderTest {

    @Mock
    private OrderProductRepository orderProductRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private CartService cartService;



    @Mock
    private NotificationService notificationService;

    @InjectMocks
    private BuyerDashBordServiceIMPL orderService;



    private User user;


    private UUID orderId;

    @InjectMocks
    private BuyerDashBordServiceIMPL buyerDashBordService;

    private UUID userId;
    private OrderProduct orderProduct;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        User user = new User();
        user.setId(userId);
        user.setFirstName("John");
        user.setPhone("1234567890");

        Cart cart = new Cart();
        List<Product> products = new ArrayList<>();
        products.add(new Product());
        cart.setProducts(products);

        user.setCart(cart);

        orderProduct = new OrderProduct();
        orderProduct.setBuyerId(userId);
        orderProduct.setStatus(Status.NEW);

        orderId = UUID.randomUUID();
        orderProduct = new OrderProduct();
        orderProduct.setOrderId(orderId);
        orderProduct.setFarmerId(UUID.randomUUID());
        orderProduct.setBuyerId(UUID.randomUUID());
        orderProduct.setProductName("Product Name");

        user = new User();
        user.setId(orderProduct.getFarmerId());
        user.setFirstName("John");
        user.setLastName("Doe");
        user.setProfileImage("image_url");
    }

    @Test
    void removeOrder_Success() {
        UUID orderId = UUID.randomUUID();
        OrderProduct orderToRemove = new OrderProduct();
        orderToRemove.setOrderId(orderId);

        when(orderProductRepository.findById(orderId)).thenReturn(Optional.of(orderToRemove));

        GenResponse response = buyerDashBordService.removeOrder(userId, orderId);

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());
        assertEquals("Order canceled", response.getMessage());
        verify(orderProductRepository, times(1)).delete(orderToRemove);
    }

    @Test
    void removeOrder_OrderNotFound() {
        UUID orderId = UUID.randomUUID();
        when(orderProductRepository.findById(orderId)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> buyerDashBordService.removeOrder(userId, orderId));
    }


}