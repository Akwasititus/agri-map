package AgricHub.Services.UserServiceImpl.FarmerProducts;

import AgricHub.Models.Dashbord.Product;
import AgricHub.Repositories.ProductRepository;
import AgricHub.Services.UserServiceImpl.ProductServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ProductServiceImpl productService;

    @Test
    void testGetAFarmersProducts() {
        String userId = "testUserId";

        Product product1 = Product.builder()
                .id(UUID.randomUUID())
                .userId(userId)
                .name("Product 1")
                .description("Description 1")
                .amount(100.0)
                .quantity(10.0)
                .imageUrl("http://example.com/image1.jpg")
                .imageKeyName("image1.jpg")
                .productCategory("Category 1")
                .productType("Type 1")
                .type("Type 1")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        Product product2 = Product.builder()
                .id(UUID.randomUUID())
                .userId(userId)
                .name("Product 2")
                .description("Description 2")
                .amount(200.0)
                .quantity(20.0)
                .imageUrl("http://example.com/image2.jpg")
                .imageKeyName("image2.jpg")
                .productCategory("Category 2")
                .productType("Type 2")
                .type("Type 2")
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();

        List<Product> mockProducts = Arrays.asList(product1, product2);
        when(productRepository.findAllByUserId(userId)).thenReturn(mockProducts);

        List<Product> result = productService.getAFarmersProducts(userId);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result).containsExactly(product1, product2);
    }
}
