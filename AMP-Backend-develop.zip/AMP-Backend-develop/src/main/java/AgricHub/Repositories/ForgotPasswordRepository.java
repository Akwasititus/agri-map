
package AgricHub.Repositories;
import AgricHub.Models.ForgotPasswords;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ForgotPasswordRepository extends JpaRepository<ForgotPasswords, String> {
    ForgotPasswords findByCode(String code);

    List<ForgotPasswords> findByEmail(String email);
}
