package AgricHub.Repositories;

import AgricHub.Models.Chat.Chat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface ChatRepository extends JpaRepository<Chat, UUID> {
    List<Chat> findAllByUserId(String userId);

    boolean existsByUserId(String userId);

    List<Chat> findAllByRecipientId(String recipientId);

    boolean existsByUserIdAndRecipientId(String userId, String recipientId);
    Chat findByUserIdAndRecipientId(String userId, String recipientId);
}
