package AgricHub.Repositories;

import AgricHub.Models.Dashbord.OrderTracking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface OrderTrackingRepository extends JpaRepository<OrderTracking, UUID> {

}
