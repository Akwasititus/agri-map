package AgricHub.Repositories;


import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface FarmerBusinessProfileRepository extends JpaRepository<FarmerBusinessProfile, UUID> {


    Optional<FarmerBusinessProfile> findByBusinessID(UUID businessID);
}
