package AgricHub.Repositories;

import AgricHub.Models.Chat.Message;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface MessageRepository extends JpaRepository<Message, UUID> {
    List<Message> findAllByUserId(String userId);

    List<Message> findAllByChatId(String chatId);
}
