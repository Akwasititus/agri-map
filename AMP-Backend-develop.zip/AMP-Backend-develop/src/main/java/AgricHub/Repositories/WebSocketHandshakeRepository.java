package AgricHub.Repositories;

import AgricHub.Models.Dashbord.WebSocketHandshake;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface WebSocketHandshakeRepository extends JpaRepository<WebSocketHandshake, UUID> {
    boolean existsByUserId(String userId);

    WebSocketHandshake findByUserId(String userId);
}
