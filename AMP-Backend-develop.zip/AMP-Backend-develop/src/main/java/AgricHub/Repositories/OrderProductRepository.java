package AgricHub.Repositories;

import AgricHub.Models.Dashbord.OrderProduct;
import AgricHub.Models.Dashbord.PaymentStatus;
import AgricHub.Models.Dashbord.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderProductRepository extends JpaRepository<OrderProduct, UUID> {


    //___________________
    // search for order
    //__________________
    List<OrderProduct> findByUsernameContainingIgnoreCase(String username);

    Page<OrderProduct> findAllByBuyerId(UUID buyerID, Pageable pageable);
    Page<OrderProduct> findAllByFarmerId(UUID buyerID, Pageable pageable);

    // ___________________
    // count orders for buyers
    // ___________________
    long countByBuyerId(UUID userId);

    long countByBuyerIdAndCreatedAtAfter(UUID userId, LocalDateTime oneWeekAgo);

    long countAllOrderMadeByBuyerIdAndCreatedAtAfter(UUID userId, LocalDateTime oneWeekAgo);


    long countByBuyerIdAndStatusAndCreatedAtAfter(UUID userId, Status status, LocalDateTime date);

    long countByBuyerIdAndStatus(UUID userId, Status status);


    //_________________________
    // count orders for farmers
    //_______________________

    @Query("SELECT COUNT(op) FROM Orders op WHERE op.farmerId = :farmerId")
    long countAllOrderByFarmerId(@Param("farmerId") UUID farmerId);

    @Query("SELECT COUNT(op) FROM Orders op WHERE op.farmerId = :farmerId AND (:status IS NULL OR op.status = :status)")
    long countAllOrdersByFarmerId(@Param("farmerId") UUID farmerId, @Param("status") Status status);

    @Query("SELECT COUNT(op) FROM Orders op WHERE op.farmerId = :farmerId AND op.status = :status AND" +
            " op.createdAt >= :createdAt")
    long countAllOrdersByFarmerIdAndStatusAndCreatedAtAfter(@Param("farmerId") UUID farmerId,
                                                            @Param("status") Status status,
                                                            @Param("createdAt") LocalDateTime createdAt);


    // get orders by status
    List<OrderProduct> findByFarmerIdAndStatus(UUID farmerId, Status status);



    @Query("SELECT op FROM Orders op WHERE op.farmerId = :farmerId")
    Page<OrderProduct> findAllOrdersForFarmerProducts(@Param("farmerId") UUID farmerId, Pageable pageable);


    List<OrderProduct> findByPaymentStatusAndCreatedAtBefore(PaymentStatus paymentStatus, LocalDateTime cutoffDate);


    List<OrderProduct> findByBuyerId(UUID buyerId);
}
