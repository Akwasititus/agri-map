package AgricHub.Repositories;

import AgricHub.Models.Dashbord.ProductImages;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ProductImagesRepository extends JpaRepository<ProductImages, UUID> {
}
