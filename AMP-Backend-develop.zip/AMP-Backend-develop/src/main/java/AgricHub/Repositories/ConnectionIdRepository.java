package AgricHub.Repositories;

import AgricHub.Models.ConnectionId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ConnectionIdRepository extends JpaRepository<ConnectionId, UUID> {
}
