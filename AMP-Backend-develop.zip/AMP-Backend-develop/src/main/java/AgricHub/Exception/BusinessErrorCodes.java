package AgricHub.Exception;


import lombok.Getter;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.NOT_IMPLEMENTED;
import static org.springframework.http.HttpStatus.LOCKED;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.FORBIDDEN;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.CONFLICT;


@Getter
public enum BusinessErrorCodes {

    NO_CODE(0, NOT_IMPLEMENTED, "No code"),

    INCORRECT_CURRENT_PASSWORD(300, BAD_REQUEST, "Current password is Incorrect"),

    NEW_PASSWORD_DOES_NOT_MATCH(301, BAD_REQUEST, "New Password does not match"),

    ACCOUNT_LOCKED(423, LOCKED, "Account locked"),

    ACCOUNT_DISABLED(403, FORBIDDEN, "Account has not been activated"),

    BAD_CREDENTIALS(401, UNAUTHORIZED, "Incorrect Password"),

    PAYMENT_UNSUCCESSFUL(400, BAD_REQUEST, "The payment was not successful"),



    TOKEN_NOT_FOUND(404, NOT_FOUND, "This could be due to the token being missing or a typo in the token code"),
    TOKEN_EXPIRED(401, UNAUTHORIZED, "Token Expiration Due to Delay"),
    USER_EMAIL_NOT_FOUND(404, NOT_FOUND, "This email does not exist"),
    USER_ROLE_NOT_FOUND(404, NOT_FOUND, "We were unable to locate your role. Are you a farmer or a buyer?"),
    USER_ALREADY_EXIST(409, CONFLICT, "The user with this email already exists"),

    INVALID_TOKEN(401, UNAUTHORIZED, "The token and the email does not match"),;


    private final int code;
    private final String description;
    private final HttpStatus httpStatus;

    BusinessErrorCodes(int code, HttpStatus httpStatus, String description) {
        this.code = code;
        this.description = description;
        this.httpStatus = httpStatus;
    }
}
