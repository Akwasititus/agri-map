
package AgricHub.Exception;

import jakarta.mail.MessagingException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MultipartException;
import java.util.HashSet;
import java.util.Set;
import static AgricHub.Exception.BusinessErrorCodes.ACCOUNT_LOCKED;
import static AgricHub.Exception.BusinessErrorCodes.USER_ALREADY_EXIST;
import static AgricHub.Exception.BusinessErrorCodes.ACCOUNT_DISABLED;
import static AgricHub.Exception.BusinessErrorCodes.BAD_CREDENTIALS;
import static AgricHub.Exception.BusinessErrorCodes.PAYMENT_UNSUCCESSFUL;
import static AgricHub.Exception.BusinessErrorCodes.TOKEN_EXPIRED;
import static AgricHub.Exception.BusinessErrorCodes.USER_EMAIL_NOT_FOUND;
import static org.springframework.http.HttpStatus.CONFLICT;
import static org.springframework.http.HttpStatus.LOCKED;
import static org.springframework.http.HttpStatus.FORBIDDEN;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(LockedException.class)
    @ResponseStatus(LOCKED)
    public ResponseEntity<ExceptionResponse> handleException(LockedException lockedException) {
        return buildResponse(LOCKED, ACCOUNT_LOCKED, lockedException);
    }

    @ExceptionHandler(MultipartException.class)
    public ResponseEntity<String> handleMultipartException(MultipartException e) {
        return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                .body("File size exceeds the maximum allowed limit.");
    }

    @ExceptionHandler(UserAlreadyExist.class)
    @ResponseStatus(CONFLICT)
    public ResponseEntity<ExceptionResponse> handleException(UserAlreadyExist userAlreadyExist) {
        return buildResponse(CONFLICT, USER_ALREADY_EXIST, userAlreadyExist);
    }

    @ExceptionHandler(DisabledException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity<ExceptionResponse> handleException(DisabledException disabledException) {
        return buildResponse(FORBIDDEN, ACCOUNT_DISABLED, disabledException);
    }

    @ExceptionHandler(BadCredentialsException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ExceptionResponse> handleException(BadCredentialsException badCredentialsException) {
        return buildResponse(UNAUTHORIZED, BAD_CREDENTIALS, badCredentialsException);
    }

    @ExceptionHandler(FailureException.class)
    @ResponseStatus(BAD_REQUEST)
    public ResponseEntity<ExceptionResponse> handleException(FailureException failureException) {
        return buildResponse(BAD_REQUEST, PAYMENT_UNSUCCESSFUL, failureException);
    }

    @ExceptionHandler(MessagingException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ExceptionResponse> handleException(MessagingException messagingException) {
        return ResponseEntity.status(INTERNAL_SERVER_ERROR)
                .body(ExceptionResponse.builder()
                        .error(messagingException.getMessage())
                        .build());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ExceptionResponse> handleException(
            MethodArgumentNotValidException argumentNotValidException) {
        Set<String> errors = new HashSet<>();
        argumentNotValidException.getBindingResult().getAllErrors()
                .forEach(error -> errors.add(error.getDefaultMessage()));
        return ResponseEntity.status(BAD_REQUEST)
                .body(ExceptionResponse.builder()
                        .validationError(errors)
                        .build());
    }

    @ExceptionHandler(TokenExpiredException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ExceptionResponse> handleException(TokenExpiredException exception) {
        return buildResponse(UNAUTHORIZED, TOKEN_EXPIRED, exception);
    }

    @ExceptionHandler(NotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ExceptionResponse> handleException(NotFoundException exception) {
        return buildResponse(NOT_FOUND, USER_EMAIL_NOT_FOUND, exception);
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ExceptionResponse> handleException(Exception exception) {
        return ResponseEntity.status(INTERNAL_SERVER_ERROR)
                .body(ExceptionResponse.builder()
                        .errorDescription("Internal error. please contact the admin")
                        .error(exception.getMessage())
                        .build());
    }

    @ExceptionHandler(InvalidTokenException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public ResponseEntity<ExceptionResponse> handleException(InvalidTokenException exception) {
        return buildResponse(UNAUTHORIZED, BusinessErrorCodes.INVALID_TOKEN, exception);
    }

    @ExceptionHandler(EmailSendingException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ExceptionResponse> handleEmailSendingException(EmailSendingException exception) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ExceptionResponse.builder()
                        .errorCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                        .errorDescription("Failed to send email")
                        .error(exception.getMessage())
                        .build());
    }

    private ResponseEntity<ExceptionResponse> buildResponse(HttpStatus status, BusinessErrorCodes errorCode,
                                                            Exception exception) {
        return ResponseEntity.status(status)
                .body(ExceptionResponse.builder()
                        .errorCode(errorCode.getCode())
                        .errorDescription(errorCode.getDescription())
                        .error(exception.getMessage())
                        .build());
    }
}
