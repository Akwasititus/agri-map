package AgricHub.Services.UserInterface;

import AgricHub.DTOs.BuyerDTOs.BuyerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import jakarta.mail.MessagingException;

public interface BuyerAuthServices {
    GenResponse registerBuyer(BuyerRegistrationDto buyerRegistrationDto) throws MessagingException;
}
