package AgricHub.Services.UserInterface;

import AgricHub.DTOs.ResponseDTOs.ProfileUpdateResponse;
import AgricHub.DTOs.UserProfile.ProfileUpdateDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

public interface ProfileService {

    ProfileUpdateResponse updateUserProfile(UUID userId, ProfileUpdateDTO profileUpdateDTO, MultipartFile file);
}
