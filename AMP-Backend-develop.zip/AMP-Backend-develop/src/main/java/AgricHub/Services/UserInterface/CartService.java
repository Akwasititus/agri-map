package AgricHub.Services.UserInterface;

import AgricHub.DTOs.FarmerDTOs.UpdateCartItemRequest;
import AgricHub.DTOs.ResponseDTOs.CartProductsResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;

import java.util.UUID;

public interface CartService {

    GenResponse addProductToCart(UUID userId, UUID productId);

    GenResponse removeProductFromCart(UUID cartId, UUID productID);


    CartProductsResponse getCartProducts(UUID userId);

    GenResponse updateProductQuantity(UpdateCartItemRequest request);

    GenResponse clearCart(UUID userId);

}
