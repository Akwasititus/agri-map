package AgricHub.Services.UserInterface;

import AgricHub.DTOs.Login.LoginDTO;
import AgricHub.DTOs.ResponseDTOs.AuthTokenResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Models.ForgotPasswords;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

public interface AuthService {

    AuthTokenResponse login(LoginDTO authenticationDto);

    GenResponse activateAccount(String token, String email) throws MessagingException;

    void refreshToken(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
            throws IOException;

    GenResponse resendActivationCode(String token, String email);

    GenResponse forgotPassword(ForgotPasswords verificationData) throws UnsupportedEncodingException,
            MessagingException;

    GenResponse verifyForgotPassword(ForgotPasswords forgotBody, HttpServletRequest requestObject);


}
