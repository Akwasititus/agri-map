package AgricHub.Services.UserInterface;

import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

public interface FarmerBusinessProfileService {
    GenResponse updateFarmerBusinessProfile(FarmerBusinessProfile profile, UUID userId, MultipartFile file,
                                            List<MultipartFile> galleryImages);

    FarmerBusinessProfile getFarmerBusinessProfileById(UUID businessId);
}
