package AgricHub.Services.UserInterface;

import AgricHub.DTOs.FarmerDTOs.FarmerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import jakarta.mail.MessagingException;

public interface FarmerAuthServices {
    GenResponse registerFarmer(FarmerRegistrationDto farmerRegistrationDto) throws MessagingException;
}
