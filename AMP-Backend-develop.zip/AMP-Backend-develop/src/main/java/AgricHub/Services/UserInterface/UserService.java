package AgricHub.Services.UserInterface;

import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.ShopResponse;
import AgricHub.DTOs.ResponseDTOs.UserResponseRequest;

import java.util.List;
import java.util.UUID;

public interface UserService {
    UserResponseRequest getUserDetails(UUID userId);


    List<ShopResponse> getAllSellers();

    GenResponse rateShop(UUID sellerId, UUID buyerId, double rate, String comment);
}
