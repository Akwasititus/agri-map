package AgricHub.Services.UserInterface;

import AgricHub.DTOs.CountOrders.CountAllCompletedOrders;
import AgricHub.DTOs.CountOrders.CountAllOrders;
import AgricHub.DTOs.CountOrders.NewOrdersCountDTOs;
import AgricHub.DTOs.ResponseDTOs.OrderResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Models.Dashbord.OrderProduct;
import AgricHub.Models.Dashbord.Status;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

public interface BuyerDashBordService {
    GenResponse createOrder(OrderProduct orderProduct);

    // fff
    Page<OrderResponse> getPageableOrderById(UUID userID, Pageable pageable);

    Page<OrderResponse> getFarmerOrders(UUID userID, Pageable pageable);

    List<OrderProduct> searchOrdersByUsername(String username);

    GenResponse updateOrderStatus(UUID orderId, Status status);

    NewOrdersCountDTOs getNewOrdersCount(UUID userId);

    CountAllOrders countAllOrders(UUID userId);

    CountAllCompletedOrders countAllCompletedOrders(UUID userId);

    List<OrderProduct> getOrderProductByStatus(UUID farmerId, Status status);

    GenResponse removeOrder(UUID userID, UUID orderID);
    Page<OrderResponse> getPageableOrdersForSeller(UUID id, Pageable pageable);
}
