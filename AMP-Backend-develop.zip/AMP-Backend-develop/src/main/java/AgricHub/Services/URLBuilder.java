package AgricHub.Services;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

public class URLBuilder {

    public static String createURLWithParams(String baseURL, List<Map.Entry<String, String>> params)
            throws UnsupportedEncodingException {
        StringBuilder urlBuilder = new StringBuilder(baseURL);

        if (params != null && !params.isEmpty()) {
            urlBuilder.append("?");
            for (Map.Entry<String, String> param : params) {
                String encodedKey = URLEncoder.encode(param.getKey(), "UTF-8");
                String encodedValue = URLEncoder.encode(param.getValue(), "UTF-8");
                urlBuilder.append(encodedKey)
                        .append("=")
                        .append(encodedValue)
                        .append("&");
            }
            // Remove the trailing '&'
            urlBuilder.deleteCharAt(urlBuilder.length() - 1);
        }

        return urlBuilder.toString();
    }

}
