package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import AgricHub.Repositories.FarmerBusinessProfileRepository;
import AgricHub.Services.UserInterface.FarmerBusinessProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;


@Service
@RequiredArgsConstructor
public class FarmerBusinessProfileServiceIMPL implements FarmerBusinessProfileService {

    private final FarmerBusinessProfileRepository farmerBusinessProfileRepository;
    private final UploadServices uploadServices;

    @Override
    public GenResponse updateFarmerBusinessProfile(FarmerBusinessProfile profile, UUID userId, MultipartFile logo,
                                                   List<MultipartFile> galleryImages) {
        FarmerBusinessProfile existingProfile = farmerBusinessProfileRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("Business Id not found"));

        // Update profile fields
        updateProfileFields(existingProfile, profile);

        // Handle logo upload
        if (logo != null && !logo.isEmpty()) {
            try {
                String logoUrl = uploadServices.uploadFileToS3(logo);
                existingProfile.setBusinessLogo(logoUrl);
            } catch (Exception e) {
                throw new RuntimeException("Failed to upload logo", e);
            }
        }

        // Handle gallery images upload
        if (galleryImages != null && !galleryImages.isEmpty()) {
            try {
                List<String> galleryUrls = uploadServices.uploadMultipleFiles(galleryImages);
                existingProfile.setBusinessGallery(galleryUrls);
            } catch (Exception e) {
                throw new RuntimeException("Failed to upload gallery images", e);
            }
        }

        farmerBusinessProfileRepository.save(existingProfile);

        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Business Profile updated successfully")
                .build();
    }


    private void updateProfileFields(FarmerBusinessProfile existingProfile, FarmerBusinessProfile updatedProfile) {
        if (updatedProfile.getBusinessCountryLocation() != null) {
            existingProfile.setBusinessCountryLocation(updatedProfile.getBusinessCountryLocation());
        }
        if (updatedProfile.getBusinessName() != null) {
            existingProfile.setBusinessName(updatedProfile.getBusinessName());
        }
        if (updatedProfile.getBusinessVision() != null) {
            existingProfile.setBusinessVision(updatedProfile.getBusinessVision());
        }
        if (updatedProfile.getBusinessFarmingPractice() != null) {
            existingProfile.setBusinessFarmingPractice(updatedProfile.getBusinessFarmingPractice());
        }
        if (updatedProfile.getBusinessCityLocation() != null) {
            existingProfile.setBusinessCityLocation(updatedProfile.getBusinessCityLocation());
        }
        if (updatedProfile.getBusinessEmail() != null) {
            existingProfile.setBusinessEmail(updatedProfile.getBusinessEmail());
        }
        if (updatedProfile.getBusinessWebsiteUrl() != null) {
            existingProfile.setBusinessWebsiteUrl(updatedProfile.getBusinessWebsiteUrl());
        }
        if (updatedProfile.getBusinessSocialMediaLinks() != null) {
            existingProfile.setBusinessSocialMediaLinks(updatedProfile.getBusinessSocialMediaLinks());
        }
        if (updatedProfile.getBusinessRegionLocation() != null) {
            existingProfile.setBusinessRegionLocation(updatedProfile.getBusinessRegionLocation());
        }
        if (updatedProfile.getBusinessProductsProduced() != null) {
            existingProfile.setBusinessProductsProduced(updatedProfile.getBusinessProductsProduced());
        }
        if (updatedProfile.getAboutUs() != null) {
            existingProfile.setAboutUs(updatedProfile.getAboutUs());
        }
        if (updatedProfile.getBusinessMission() != null) {
            existingProfile.setBusinessMission(updatedProfile.getBusinessMission());
        }
        if (updatedProfile.getBusinessContact() != null) {
            existingProfile.setBusinessContact(updatedProfile.getBusinessContact());
        }
    }


    @Override
    public FarmerBusinessProfile getFarmerBusinessProfileById(UUID businessId) {
        return farmerBusinessProfileRepository.findById(businessId)
                .orElseThrow(() -> new NotFoundException("Business profile not found for id: " + businessId));
    }
}
