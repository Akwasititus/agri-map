package AgricHub.Services.UserServiceImpl.SocketService;

import AgricHub.Models.User;
import AgricHub.Repositories.UserRepository;
import com.sun.security.auth.UserPrincipal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.support.DefaultHandshakeHandler;

import java.security.Principal;
import java.util.Map;
import java.util.UUID;

public class UserHandshakeHandler extends DefaultHandshakeHandler {

    private final Logger log = LoggerFactory.getLogger(UserHandshakeHandler.class);

    @Autowired
    private UserRepository userRepository;

    @Override
    protected Principal determineUser(ServerHttpRequest request, WebSocketHandler wsHandler,
                                      Map<String, Object> attributes) {
        // Retrieve user ID from WebSocket handshake attributes
        String userId = getUserIdFromRequest(request);

        if (!userId.equals("No Ids found")) {
            try {
                // Fetch user by user ID
                User user = userRepository.findById(UUID.fromString(userId)).orElse(null);

                if (user != null) {
                    String userUniqueId = user.getId().toString();
                    log.info("User with Id {} is active", userUniqueId);
                    return new UserPrincipal(userUniqueId);
                }
            } catch (IllegalArgumentException e) {
                log.warn("Invalid UUID format for userId: {}", userId);
            }
        }

        // If user is not found or userId is invalid, generate a random ID
        String id = UUID.randomUUID().toString();

        log.info("User with random Id {} is active", id);
        return new UserPrincipal(id);
    }

    private static String getUserIdFromRequest(ServerHttpRequest request) {
        if (request instanceof ServletServerHttpRequest servletRequest) {
            String userId = servletRequest.getServletRequest().getHeader("UserId");
            if (userId != null) {
                return userId;
            }
        }
        return "No Ids found";
    }
}
