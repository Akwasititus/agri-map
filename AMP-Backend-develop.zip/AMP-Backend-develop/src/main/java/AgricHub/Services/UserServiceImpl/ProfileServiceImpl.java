package AgricHub.Services.UserServiceImpl;
import AgricHub.DTOs.ResponseDTOs.ProfileUpdateResponse;
import AgricHub.DTOs.ResponseDTOs.UpdatedUserInfoDTO;
import AgricHub.DTOs.UserProfile.ProfileUpdateDTO;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.User;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.ProfileService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.util.UUID;


@Service
@RequiredArgsConstructor
public class ProfileServiceImpl implements ProfileService {

    private final UserRepository userRepository;
    private final UploadServices uploadServices;


    @Value("${aws.s3.bucket}")
    String bucketName;

    @Override
    @Transactional
    public ProfileUpdateResponse updateUserProfile(UUID userId, ProfileUpdateDTO profileUpdateDTO, MultipartFile file) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found"));

        UpdatedUserInfoDTO.UpdatedUserInfoDTOBuilder updatedInfoBuilder = UpdatedUserInfoDTO.builder();

        if (profileUpdateDTO.getFirstName() != null) {
            user.setFirstName(profileUpdateDTO.getFirstName());
        }
        if (profileUpdateDTO.getLastName() != null) {
            user.setLastName(profileUpdateDTO.getLastName());
        }
        if (profileUpdateDTO.getPhone() != null) {
            user.setPhone(profileUpdateDTO.getPhone());
        }

        user.setShopName(profileUpdateDTO.getShopName());


        // Upload profile picture to S3 if provided
        if (file != null && !file.isEmpty()) {
            String fileUrl = uploadServices.uploadFileToS3(file);
            user.setProfileImage(fileUrl);
            updatedInfoBuilder.profileImage(fileUrl);

        }

        updatedInfoBuilder.firstName(profileUpdateDTO.getFirstName());
        updatedInfoBuilder.lastName(profileUpdateDTO.getLastName());
        updatedInfoBuilder.phone(profileUpdateDTO.getPhone());
        updatedInfoBuilder.organizationName(profileUpdateDTO.getShopName());

        userRepository.saveAndFlush(user);

        return ProfileUpdateResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Profile Updated Successfully")
                .data(updatedInfoBuilder.build())
                .build();
    }
}




