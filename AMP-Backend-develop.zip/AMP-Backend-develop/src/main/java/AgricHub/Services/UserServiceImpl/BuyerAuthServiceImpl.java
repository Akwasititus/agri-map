package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.BuyerDTOs.BuyerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.EmailSendingException;
import AgricHub.Exception.UserAlreadyExist;
import AgricHub.Models.Dashbord.Cart;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.Roles.RoleEnum;
import AgricHub.Models.User;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.BuyerAuthServices;
import AgricHub.Email.EmailTokenService;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.SIGN_UP_SUCCESS;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.USER_ALREADY_EXIST;

@Service
@RequiredArgsConstructor
public class BuyerAuthServiceImpl implements BuyerAuthServices {


    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailTokenService emailTokenService;



    @Override
    public GenResponse registerBuyer(BuyerRegistrationDto buyerRegistrationDto) {

        var existingUser = userRepository.findByEmail(buyerRegistrationDto.getEmail().trim());
        if (existingUser.isPresent()) {
            throw new UserAlreadyExist(USER_ALREADY_EXIST);
        }


        var user = User.builder()
                .email(buyerRegistrationDto.getEmail())
                .password(passwordEncoder.encode(buyerRegistrationDto.getPassword()))
                .firstName(buyerRegistrationDto.getFirstName())
                .lastName(buyerRegistrationDto.getLastName())
                .profileImage(buyerRegistrationDto.getProfileImage())
                .phone(buyerRegistrationDto.getPhone())

                // check on this
                .country(buyerRegistrationDto.getCountry())
                .region(buyerRegistrationDto.getRegion())
                .city(buyerRegistrationDto.getCity())

                .accountLocked(false)
                .enabled(false)
                .roleEnum(RoleEnum.BUYER)
                .build();




        List<Product> product = new ArrayList<>();
        Cart cart = Cart.builder()
                .price(0.0)
                .productCount(0)
                .userEmail(user.getEmail())
                .products(product)
                .build();
        cart.updateTotalPrice();

        user.setCart(cart);

        userRepository.save(user);


        try {
            // Call sendValidationEmail method from EmailTokenService
            emailTokenService.sendValidationEmail(user);
        } catch (MessagingException e) {
            throw new EmailSendingException("Error sending validation email", e);
        }

        return GenResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message(SIGN_UP_SUCCESS).build();
    }
}
