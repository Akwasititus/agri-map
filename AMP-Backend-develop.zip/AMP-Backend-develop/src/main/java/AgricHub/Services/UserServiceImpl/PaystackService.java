package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.Payment.PaystackSubaccountRequest;
import AgricHub.DTOs.ResponseDTOs.BanksResponses;
import AgricHub.DTOs.ResponseDTOs.PaystackBanksResponse;
import AgricHub.DTOs.ResponseDTOs.PaystackSubaccountResponse;
import AgricHub.Exception.FailureException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaystackService {





    @Value("${paystack_secreteKey}")
    String paystackSecreteKey;

    @Value("${paystack_url}")
    String paystackBaseUrl;

    @Value("${paystack_subaccount}")
    String subAccountUrl;

    @Value("${banks}")
    String banks;

    private final RestTemplate restTemplate;

    public PaystackSubaccountResponse createSubaccount(PaystackSubaccountRequest request) {
        String url = paystackBaseUrl + subAccountUrl;
        HttpHeaders headers = createHeaders();
        HttpEntity<PaystackSubaccountRequest> entity = new HttpEntity<>(request, headers);

        try {
            ResponseEntity<PaystackSubaccountResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    PaystackSubaccountResponse.class
            );

            if (response.getStatusCode() == HttpStatus.CREATED) {
                return response.getBody();
            } else {
                throw new FailureException("Failed to create subaccount. Status: " + response.getStatusCode());
            }
        } catch (RestClientException e) {
            throw new FailureException("Error while calling Paystack API");
        }
    }


    public List<BanksResponses> createBanks() {
        String url = paystackBaseUrl + banks;

        HttpHeaders headers = createHeaders();
        HttpEntity<String> entity = new HttpEntity<>(headers);

        try {
            ResponseEntity<PaystackBanksResponse> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    PaystackBanksResponse.class
            );

            if (response.getStatusCode() == HttpStatus.OK) {
                PaystackBanksResponse paystackResponse = response.getBody();
                if (paystackResponse != null) {
                    return mapToBanksResponses(paystackResponse);
                } else {
                    throw new FailureException("Paystack response is null");
                }
            } else {
                throw new FailureException("Failed to get banks " + response.getStatusCode());
            }
        } catch (RestClientException e) {
            throw new FailureException("Error while calling Paystack API");
        }
    }


    private HttpHeaders createHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(paystackSecreteKey);
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }


    private  List<BanksResponses> mapToBanksResponses(PaystackBanksResponse paystackResponse) {
        return paystackResponse.getData().stream()
                .map(bank -> {
                    BanksResponses response = new BanksResponses();
                    response.setBankName(bank.getName());
                    response.setBankCode(bank.getCode());
                    return response;
                })
                .collect(Collectors.toList());
    }

}




