
package AgricHub.Services.UserServiceImpl;
import AgricHub.DTOs.Products.ProductImagesDTO;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.Dashbord.ProductImages;
import AgricHub.Repositories.ProductImagesRepository;
import AgricHub.Repositories.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.core.io.Resource;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SingleFileUploadService {


    private final ProductRepository productRepository;
    private final ProductImagesRepository productRepositoryDTO;
    private static final String UPLOAD_DIR = "uploads/";

    @Transactional
    public String uploadProductImage(UUID id, MultipartFile imageFile) throws IOException {
        Optional<Product> optionalProduct = productRepository.findById(id);


        Product product = optionalProduct.get();

        // Create the uploads directory if it doesn't exist
        Files.createDirectories(Paths.get(UPLOAD_DIR));

        // Get the file's original name and construct the file path
        String fileName = UUID.randomUUID() + "_" + imageFile.getOriginalFilename();
        String filePath = UPLOAD_DIR + fileName;

        // Save the file locally
        Files.write(Paths.get(filePath), imageFile.getBytes());

        // Update the product with the image URL/path
        product.setImageUrl(filePath);
        productRepository.save(product);

        return filePath;
    }

    @Transactional
    public Resource loadImageAsResource(String id) throws IOException {
        Optional<Product> optionalProduct = productRepository.findById(UUID.fromString(id));
        if (optionalProduct.isEmpty()) {
            throw new IOException("Product not found");
        }

        Product product = optionalProduct.get();
        Path imagePath = Paths.get(product.getImageUrl());
        try {
            Resource resource = (Resource) new UrlResource(imagePath.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                throw new IOException("Could not read file: " + imagePath);
            }
        } catch (MalformedURLException e) {
            throw new IOException("Malformed URL for file: " + imagePath, e);
        }
    }

    @Transactional
    public String bulkUpload(List<ProductImagesDTO> productImagesList) throws IOException {
        for (ProductImagesDTO productImage : productImagesList) {
            productRepositoryDTO.save(
                    ProductImages
                            .builder()
                            .name(productImage.getFile().getName())
                            .destinationId(productImage.getProductId())
                            .filePath(uploadProductImage(UUID.randomUUID(), productImage.getFile()))
                            .build()
            );
        }
        return "Upload successful"; // Return a success message or handle as needed
    }

}
