package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.FarmerDTOs.FarmerRegistrationDto;

import AgricHub.DTOs.Payment.PaystackSubaccountRequest;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.PaystackSubaccountResponse;
import AgricHub.Exception.EmailSendingException;
import AgricHub.Exception.UserAlreadyExist;
import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import AgricHub.Models.Dashbord.Cart;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.Roles.RoleEnum;
import AgricHub.Models.User;
import AgricHub.Repositories.FarmerBusinessProfileRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Email.EmailTokenService;
import AgricHub.Services.UserInterface.FarmerAuthServices;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.SIGN_UP_SUCCESS;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.USER_ALREADY_EXIST;


@Service
@RequiredArgsConstructor
public class FarmerAuthServicesImpl implements FarmerAuthServices {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailTokenService emailTokenService;
    private final FarmerBusinessProfileRepository farmerBusinessProfileRepository;
    private final PaystackService paystackService;



    @Override
    public GenResponse registerFarmer(FarmerRegistrationDto farmerRegistrationDto) {


        var existingUser = userRepository.findByEmail(farmerRegistrationDto.getEmail().trim());
        if (existingUser.isPresent()) {
            throw new UserAlreadyExist(USER_ALREADY_EXIST);
        }

        // Create and save the farmer business profile
        FarmerBusinessProfile profile = new FarmerBusinessProfile();
        profile.setBusinessID(profile.getBusinessID());
        profile.setBusinessVision("");
        profile.setAboutUs("");
        profile.setBusinessEmail("");
        profile.setBusinessContact("");
        profile.setBusinessMission("");
        profile.setBusinessCityLocation("");
        profile.setBusinessLogo("");
        profile.setBusinessName("");
        profile.setBusinessRegionLocation("");
        profile.setBusinessWebsiteUrl("");
        profile.setBusinessCountryLocation("");
        profile.setBusinessProductsProduced(Collections.singletonList(""));
        profile.setBusinessFarmingPractice(Collections.singletonList(""));
        profile.setBusinessGallery(Collections.singletonList(""));
        profile.setBusinessSocialMediaLinks(Collections.singletonList(""));

        farmerBusinessProfileRepository.save(profile);

        var user = User.builder()
                .email(farmerRegistrationDto.getEmail())
                .password(passwordEncoder.encode(farmerRegistrationDto.getPassword()))
                .firstName(farmerRegistrationDto.getFirstName())
                .lastName(farmerRegistrationDto.getLastName())
                .phone(farmerRegistrationDto.getPhone())
                .businessID(profile.getBusinessID())
                .shopName(farmerRegistrationDto.getShopName())
                .country(farmerRegistrationDto.getCountry())
                .region(farmerRegistrationDto.getRegion())
                .city(farmerRegistrationDto.getCity())
                .settlementBank(farmerRegistrationDto.getSettlementBank())
                .accountNumber(farmerRegistrationDto.getAccountNumber())
                .profileImage(farmerRegistrationDto.getProfileImage())
                .accountLocked(false)
                .enabled(false)
                .roleEnum(RoleEnum.FARMER)
                .build();

        List<Product> product = new ArrayList<>();
        Cart cart = Cart.builder()
                .products(product)
                .build();

        user.setCart(cart);
        userRepository.save(user);

        try {

            // Create Paystack Subaccount
            PaystackSubaccountRequest subaccountRequest = new PaystackSubaccountRequest();

            subaccountRequest.setBusinessName(farmerRegistrationDto.getShopName());
            subaccountRequest.setSettlementBank(farmerRegistrationDto.getSettlementBank());
            subaccountRequest.setAccountNumber(farmerRegistrationDto.getAccountNumber());
            subaccountRequest.setPercentageCharge(5); // the percentage the main account
            // receives from each payment made to the subaccount

            PaystackSubaccountResponse subaccountResponse = paystackService.createSubaccount(subaccountRequest);

            user.setBusinessName(subaccountResponse.getData().getBusinessName());
            user.setSettlementBank(subaccountResponse.getData().getSettlementBank());
            user.setAccountNumber(subaccountResponse.getData().getAccountNumber());
            user.setSubAccountCode(subaccountResponse.getData().getSubAccountCode());
            userRepository.save(user);

            // Call sendValidationEmail method from EmailTokenService
            emailTokenService.sendValidationEmail(user);
        } catch (MessagingException e) {
            throw new EmailSendingException("Error sending validation email", e);
        }

        return GenResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message(SIGN_UP_SUCCESS).build();

    }

}
