package AgricHub.Services.UserServiceImpl.SocketService;

import AgricHub.DTOs.ResponseDTOs.AllUnseenNotificationResponse;
import AgricHub.DTOs.ResponseDTOs.SuccessWebSocketHandshake;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.ConnectionId;
import AgricHub.Models.Dashbord.Notification;
import AgricHub.Models.Dashbord.NotificationType;
import AgricHub.Models.Dashbord.WebSocketHandshake;
import AgricHub.Records.WebSocketHSRequest;
import AgricHub.Repositories.ConnectionIdRepository;
import AgricHub.Repositories.NotificationRepository;
import AgricHub.Repositories.WebSocketHandshakeRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final SimpMessagingTemplate messagingTemplate;
    private final ConnectionIdRepository connectionIdRepository;
    private final NotificationRepository notificationRepository;
    private final WebSocketHandshakeRepository webSocketHandshakeRepository;

    public SuccessWebSocketHandshake initiateHandshake(WebSocketHSRequest request) {
        boolean isUserSocketAlreadyAvailable = webSocketHandshakeRepository.existsByUserId(request.userId());
        WebSocketHandshake existHandshake = webSocketHandshakeRepository.findByUserId(request.userId());

        if (isUserSocketAlreadyAvailable) {
            webSocketHandshakeRepository.save(WebSocketHandshake
                    .builder()
                    .id(existHandshake.getId())
                    .socketId(request.socketId())
                    .userId(request.userId())
                    .build());
            return SuccessWebSocketHandshake
                    .builder()
                    .status(HttpStatus.ACCEPTED.value())
                    .message("Websocket Handshake Successful!")
                    .build();
        } else {
            webSocketHandshakeRepository.save(
                    WebSocketHandshake
                            .builder()
                            .socketId(request.socketId())
                            .userId(request.userId())
                            .build());

            return SuccessWebSocketHandshake
                    .builder()
                    .status(HttpStatus.ACCEPTED.value())
                    .message("Websocket Handshake Successful!")
                    .build();
        }
    }

    public void sendNotification(String userId, Notification notification) {
        WebSocketHandshake userSocketId = webSocketHandshakeRepository.findByUserId(userId);

        if (userSocketId == null) {
            throw new NotFoundException("User socket not found for userId: " + userId);
        }

        notificationRepository.save(notification);

        Notification
                .builder()
                .notificationType(NotificationType.ACTIVE)
                .build();
        connectionIdRepository.save(ConnectionId
                .builder()
                .userId(notification.getUserId())
                .title(notification.getTitle())
                .message(notification.getDescription())
                .seen(false)
                .build());
        messagingTemplate.convertAndSendToUser(userSocketId.getSocketId(), "/queue/private", notification);
    }

    public AllUnseenNotificationResponse getAllUnseenNotifications(String userId) {
        List<Notification> allNotifications = notificationRepository.findAllByUserId(userId);

        return AllUnseenNotificationResponse
                .builder()
                .status(HttpStatus.OK.value())
                .message("All your pending notifications!")
                .notifications(allNotifications)
                .build();
    }

    @Transactional
    public void markAllAsRead(String userId) {
        List<Notification> allNotifications = notificationRepository.findAllByUserId(userId);

        for (Notification notification : allNotifications) {
            notification.setSeen(true);
        }

        notificationRepository.saveAll(allNotifications);
    }
}
