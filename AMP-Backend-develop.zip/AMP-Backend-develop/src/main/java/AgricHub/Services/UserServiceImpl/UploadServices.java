package AgricHub.Services.UserServiceImpl;

import AgricHub.Exception.FailureException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UploadServices {

    private final AmazonS3 amazonS3;

    @Value("${aws.s3.bucket}")
    private String bucketName;

    public String uploadFileToS3(MultipartFile file) {
        try {
            String fileName = generateUniqueFileName(file.getOriginalFilename());
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentType(file.getContentType());
            metadata.setContentLength(file.getSize());

            amazonS3.putObject(new PutObjectRequest(bucketName, fileName, file.getInputStream(), metadata));
            String fileUrl = amazonS3.getUrl(bucketName, fileName).toString();

            return fileUrl;
        } catch (IOException e) {
            throw new FailureException("Failed to upload file to S3");
        }
    }

    public List<String> uploadMultipleFiles(List<MultipartFile> files) {
        List<String> uploadedFileUrls = new ArrayList<>();
        for (MultipartFile file : files) {
            uploadedFileUrls.add(uploadFileToS3(file));
        }
        return uploadedFileUrls;
    }

    private String generateUniqueFileName(String originalFilename) {
        return UUID.randomUUID() + "-" + originalFilename;
    }
}
