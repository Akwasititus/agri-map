package AgricHub.Services.UserServiceImpl;

import AgricHub.Models.Dashbord.OrderProduct;
import AgricHub.Models.Dashbord.PaymentStatus;
import AgricHub.Repositories.OrderProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderCleanupService {

    public final OrderProductRepository orderProductRepository;

    @Scheduled(cron = "0 0 0 * * ?") // Runs every day at midnight
public void deleteUnpaidOrders() {

    LocalDateTime cutoffDate = LocalDateTime.now().minusDays(10);
    List<OrderProduct> unpaidOrders = orderProductRepository.
            findByPaymentStatusAndCreatedAtBefore(PaymentStatus.PENDING, cutoffDate);

    orderProductRepository.deleteAll(unpaidOrders);
    }
}
