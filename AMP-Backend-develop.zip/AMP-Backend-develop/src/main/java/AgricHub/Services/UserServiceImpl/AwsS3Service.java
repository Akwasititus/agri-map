
package AgricHub.Services.UserServiceImpl;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URL;

@Service
@RequiredArgsConstructor
public class AwsS3Service {

    private final AmazonS3 s3client;

    @Value("${aws.s3.bucket}")
    String bucketName;

    public URL uploadFile(String keyName, MultipartFile file) throws IOException {
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(file.getSize());
        metadata.setContentType(file.getContentType());

        PutObjectResult putObjectResult = s3client.putObject(bucketName, keyName, file.getInputStream(), metadata);

        return s3client.getUrl(bucketName, keyName);
    }

    public S3Object getFile(String keyName) {
        return s3client.getObject(bucketName, keyName);
    }

    public GenResponse deleteFile(String keyName) {
        s3client.deleteObject(bucketName, keyName);
        return GenResponse
                .builder()
                .status(HttpStatus.OK.value())
                .message("File Deleted Successfully!")
                .build();
    }
}
