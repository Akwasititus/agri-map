package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.ResponseDTOs.WebhookPaymentResponse.WebhookPaymentSuccessResponse;
import AgricHub.DTOs.Payment.PaymentRequest;
import AgricHub.DTOs.ResponseDTOs.InitializationResponse.InitializeTransactionResponse;
import AgricHub.DTOs.ResponseDTOs.VerifyTransactionResponse;
import AgricHub.Exception.FailureException;
import AgricHub.Exception.NotFoundException;


import AgricHub.Models.Dashbord.OrderProduct;
import AgricHub.Models.Dashbord.PaymentStatus;
import AgricHub.Models.Dashbord.PaymentTransaction;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.User;


import AgricHub.Repositories.OrderProductRepository;
import AgricHub.Repositories.PaymentTransactionRepository;
import AgricHub.Repositories.ProductRepository;
import AgricHub.Repositories.UserRepository;
import com.google.gson.Gson;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.LocalDateTime;


import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;


import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.NOT_FOUND;

@Service
@RequiredArgsConstructor
public class PaymentIMPL {


    @Value("${paystack_secreteKey}")
    String paystackSecreteKey;

    @Value("${paystack_transaction_url}")
    String paystackTransactionUrl;

    @Value("${paystack_verify_transaction_url}")
    String paystackVerifyTransactionUrl;

    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final PaymentTransactionRepository paymentTransactionRepository;
    private final OrderProductRepository orderProductRepository;




    public InitializeTransactionResponse initializeTransaction(PaymentRequest request) {
        InitializeTransactionResponse initializeTransactionResponse;
        try {
            // convert transaction to json then use it as a body to post json
            Gson gson = new Gson();
            // add paystack chrges to the amount


            Map<String, Object> metadata = new HashMap<>();
            metadata.put("orderId", request.getOrderId());
            metadata.put("buyerId", request.getBuyerId());

            Map<String, Object> body = new HashMap<>();
            body.put("email", request.getEmail());
            body.put("amount", request.getAmount() * 100);
            body.put("subaccount", request.getSubaccount());
            body.put("share", 95);


            body.put("metadata", metadata);




            StringEntity postingString = new StringEntity(gson.toJson(body));
            HttpClient client = HttpClientBuilder.create().build();
            HttpPost post = new HttpPost(paystackTransactionUrl);
            post.setEntity(postingString);
            post.addHeader("Content-type", "application/json");
            post.addHeader("Authorization", "Bearer " + paystackSecreteKey);
            StringBuilder result = new StringBuilder();
            HttpResponse response = client.execute(post);

            if (response.getStatusLine().getStatusCode() == 200) {
                BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

                String line;
                while ((line = rd.readLine()) != null) {
                    result.append(line);
                }

            } else {
                throw new FailureException("Error Occurred while initializing transaction");
            }
            ObjectMapper mapper = new ObjectMapper();

            initializeTransactionResponse = mapper.readValue(result.toString(), InitializeTransactionResponse.class);
        } catch (Exception ex) {
            throw new FailureException("Failure initializaing paystack transaction");
        }

        return initializeTransactionResponse;
    }

    @Transactional
    public VerifyTransactionResponse verifyTransaction(String reference) {
        VerifyTransactionResponse verifyTransactionResponse;

        String verificationUrl = paystackVerifyTransactionUrl + reference;


        // Using try-with-resources to automatically close resources
        try (CloseableHttpClient client = HttpClientBuilder.create().build()) {
            HttpGet get = new HttpGet(verificationUrl);

            get.addHeader("Content-type", "application/json");
            get.addHeader("Authorization", "Bearer " + paystackSecreteKey);

            StringBuilder result = new StringBuilder();
            try (CloseableHttpResponse response = client.execute(get)) {
                // Log the response status
                int statusCode = response.getStatusLine().getStatusCode();


                if (statusCode == org.apache.http.HttpStatus.SC_OK) {
                    try (BufferedReader rd = new BufferedReader(new InputStreamReader(
                            response.getEntity().getContent()))) {
                        String line;
                        while ((line = rd.readLine()) != null) {
                            result.append(line);
                        }
                    }
                } else {
                    throw new FailureException("Error occurred while verifying transaction. Status code: " +
                            statusCode);
                }
            }

            ObjectMapper mapper = new ObjectMapper();
            verifyTransactionResponse = mapper.readValue(result.toString(), VerifyTransactionResponse.class);

        } catch (Exception ex) {

            throw new FailureException("Failed to verify Paystack transaction");
        }

        return verifyTransactionResponse;
    }



    @Transactional
    public void processWebhook(WebhookPaymentSuccessResponse payload) {

        if ("charge.success".equals(payload.getEvent())) {
            String reference = payload.getData().getReference();

            try {
                VerifyTransactionResponse verificationResponse = verifyTransaction(reference);

                // Ensure the user exists
                Optional<User> userOptional = userRepository.findById(UUID.fromString(payload.getData().getMetadata()
                        .getBuyerId()));
                if (userOptional.isEmpty()) {
                    throw new NotFoundException(NOT_FOUND);
                }
                User user = userOptional.get();



                List<OrderProduct> orderProduct = orderProductRepository.findByBuyerId(UUID.fromString(payload.getData()
                        .getMetadata().getBuyerId()));

                if (verificationResponse.getData().getStatus().equals("success")) {
                    for (OrderProduct order : orderProduct) {
                        order.setUpdatedAt(LocalDateTime.now());
                        order.setPaymentStatus(PaymentStatus.PAID);
                        orderProductRepository.save(order);
                    }




                    for (OrderProduct product : orderProduct) {
                        // Check if the transaction with the same transactionId already exists
                        Optional<PaymentTransaction> existingTransaction = paymentTransactionRepository
                                .findByTransactionId(reference);
                        if (existingTransaction.isEmpty()) {
                            // save transactions
                            PaymentTransaction paymentTransaction = PaymentTransaction.builder()
                                    .buyerId(user.getId())
                                    .productId(product.getProductId())
                                    .productName(product.getProductName())
                                    .amount(payload.getData().getAmount())
                                    .email(user.getEmail())
                                    .userName(user.getFirstName())
                                    .phoneNumbers(user.getPhone())
                                    .transactionId(reference)
                                    .createdAt(LocalDateTime.now())
                                    .build();

                            paymentTransactionRepository.save(paymentTransaction);
                        }

                       Optional<Product> newProduct =  productRepository.findById(product.getProductId());

                        Product product1 = Product.builder()
                                .amount(newProduct.get().getAmount())
                                .name(newProduct.get().getName())
                                .quantity(newProduct.get().getQuantity() - newProduct.get().getOrderQuantity())
                                .description(newProduct.get().getDescription())
                                .imageKeyName(newProduct.get().getImageKeyName())
                                .imageUrl(newProduct.get().getImageUrl())
                                .productCategory(newProduct.get().getProductCategory())
                                .productType(newProduct.get().getProductType())
                                .id(newProduct.get().getId())
                                .userId(newProduct.get().getUserId())
                                .createdAt(newProduct.get().getCreatedAt())
                                .type(newProduct.get().getProductType())
                                .updatedAt(newProduct.get().getUpdatedAt())
                                .orderQuantity(newProduct.get().getOrderQuantity())
                                .build();
                        productRepository.save(product1);
                    }


                } else {
                    for (OrderProduct order : orderProduct) {
                        order.setUpdatedAt(LocalDateTime.now());
                        order.setPaymentStatus(PaymentStatus.FAILED);
                        orderProductRepository.save(order);
                    }

                }

            } catch (Exception e) {
                throw new FailureException("Error verifying payment: " + e.getMessage());
            }
        } else {
            throw new FailureException("Payment was not successful");
        }
    }




    public List<Product> getMostBoughtProducts(int limit, UUID userId) {

        List<PaymentTransaction> allTransactions = paymentTransactionRepository.findByBuyerId(userId);

        Map<UUID, Long> productPurchaseCounts = allTransactions.stream()
                .collect(Collectors.groupingBy(PaymentTransaction::getProductId, Collectors.counting()));

        List<UUID> topProductIds = productPurchaseCounts.entrySet().stream()
                .sorted(Map.Entry.<UUID, Long>comparingByValue().reversed())
                .limit(limit)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        return productRepository.findAllById(topProductIds);
    }
}




