
package AgricHub.Services.UserServiceImpl;
import AgricHub.DTOs.CountOrders.CountAllCompletedOrders;
import AgricHub.DTOs.CountOrders.CountAllOrders;
import AgricHub.DTOs.CountOrders.NewOrdersCountDTOs;
import AgricHub.DTOs.ResponseDTOs.OrderResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.NotFoundException;

import AgricHub.Models.Dashbord.Cart;
import AgricHub.Models.Dashbord.Status;
import AgricHub.Models.Dashbord.NotificationType;
import AgricHub.Models.Dashbord.Notification;
import AgricHub.Models.Dashbord.OrderProduct;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.Roles.RoleEnum;
import AgricHub.Models.User;
import AgricHub.Repositories.OrderProductRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.BuyerDashBordService;
import AgricHub.Services.UserInterface.CartService;
import AgricHub.Services.UserServiceImpl.SocketService.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.NOT_FOUND;



@Service
@RequiredArgsConstructor
public class BuyerDashBordServiceIMPL implements BuyerDashBordService {

    private final OrderProductRepository orderProductRepository;
    private final UserRepository userRepository;
    private final CartService cartService;
    private final NotificationService notificationService;



    @Override
    public GenResponse createOrder(OrderProduct orderProduct) {
        // Ensure the user exists
        User user = findUserById(orderProduct.getBuyerId());

        // Ensure the cart exists for the user
        Cart userCart = findCartByUser(user);

        // Set the pick-up date
        LocalDateTime pickUpDate = LocalDateTime.now().plusDays(3);
        orderProduct.setPickUpDate(pickUpDate);

        // Create orders for each product in the cart
        createOrdersForCartProducts(user, orderProduct, userCart);

        cartService.clearCart(user.getId());

        // Return response
        return GenResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message("Orders created successfully")
                .build();
    }

    private User findUserById(UUID buyerId) {
        return userRepository.findById(buyerId)
                .orElseThrow(() -> new NotFoundException(NOT_FOUND));
    }

    private Cart findCartByUser(User user) {
        Cart userCart = user.getCart();
        if (userCart == null) {
            throw new NotFoundException("Cart not found for user");
        }
        return userCart;
    }



    private void createOrdersForCartProducts(User user, OrderProduct orderProduct, Cart userCart) {
        List<OrderProduct> newOrders = new ArrayList<>();
        for (Product product : userCart.getProducts()) {
            UUID farmerId = UUID.fromString(product.getUserId());
            Optional<User> farmer = userRepository.findById(farmerId);


                notificationService.sendNotification(product.getUserId(), Notification
                        .builder()
                        .title("New Order Received ")
                        .description("You have a new order! Order has been placed by " + user.getFirstName() +
                                ". Please review the order details and prepare for shipment.")
                        .userId(product.getUserId())
                        .userProfileImage(user.getProfileImage())
                        .createdAt(LocalDateTime.now())
                        .notificationType(NotificationType.NEW_ORDER)
                        .seen(false)
                        .build());

                notificationService.sendNotification(String.valueOf(user.getId()), Notification
                        .builder()
                        .title("Order Confirmation ")
                        .description("Thank you for your purchase!" +
                                " Your order has been successfully placed. We will notify you once it's shipped.")
                        .userId(String.valueOf(user.getId()))
                        .userProfileImage(farmer.get().getProfileImage())
                        .createdAt(LocalDateTime.now())
                        .notificationType(NotificationType.NEW_ORDER)
                        .seen(false)
                        .build());


            OrderProduct newOrder = OrderProduct.builder()
                    .orderId(orderProduct.getOrderId())
                    .buyerId(orderProduct.getBuyerId())
                    .farmerId(farmerId)
                    .amount(product.getAmount())
                    .status(orderProduct.getStatus())
                    .productName(product.getName())
                    .productPrice(product.getAmount())
                    .productQuantity(product.getQuantity())
                    .productId(product.getId())
                    .userEmail(user.getEmail())
                    .orderQuantity(product.getOrderQuantity())
                    .shopName(farmer.get().getShopName())
                    .username(user.getFirstName() + " " + user.getLastName())
                    .phoneNumber(user.getPhone())
                    .location(user.getCity())
                    .pickUpDate(orderProduct.getPickUpDate())
                    .paymentStatus(orderProduct.getPaymentStatus())
                    .createdAt(LocalDateTime.now())
                    .build();
            newOrders.add(newOrder);

            orderProductRepository.save(newOrder);


        }
    }




    @Override
    public GenResponse removeOrder(UUID userID, UUID orderID) {

        Optional<OrderProduct> order = orderProductRepository.findById(orderID);
        if (order.isEmpty()) {
            throw new NotFoundException("Order not found for orderID");
        }
        OrderProduct orderProduct = order.get();
        orderProductRepository.delete(orderProduct);

        // Response
        return GenResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message("Order canceled")
                .build();
    }

    @Override
    public GenResponse updateOrderStatus(UUID orderId, Status newStatus) {

        // Retrieve the order from the repository
        Optional<OrderProduct> optionalOrder = orderProductRepository.findById(orderId);

        if (optionalOrder.isEmpty()) {
            throw new NotFoundException(NOT_FOUND);
        }

        OrderProduct order = optionalOrder.get();

        // Set the new status directly
        order.setStatus(newStatus);

        // Save the updated order back to the repository
        orderProductRepository.save(order);

        User user = findUserById(order.getFarmerId());

        String notificationDescription = "";
        String titleNotification = "";


        switch (newStatus) {

            case NEW:
                titleNotification = "New Order Received";
                notificationDescription = "Your order from " + user.getFirstName() + " " + user.getLastName()
                        + " is currently being processed. ";
                break;

            case PROCESSING:
                titleNotification = "Order " + order.getProductName() + " is In Processing";
                notificationDescription = "Your order from " + user.getFirstName() + " " + user.getLastName()
                        + " is currently being processed. ";
                break;
            case COMPLETED:
                titleNotification = "Order Completed";
                notificationDescription = "Good news! Your order for " + order.getProductName()
                        + " has been completed and is on its way.";
                break;
            case CANCELLED:
                titleNotification = "Order Cancelled";
                notificationDescription = "Your order for " + order.getProductName()
                        + " We're sorry to inform you that your order has been cancelled." +
                        " If you have any questions, please contact our support team";
                break;
            default:

                break;
        }

        notificationService.sendNotification(String.valueOf(order.getBuyerId()), Notification
                .builder()
                .title(titleNotification)
                .description(notificationDescription)
                .userId(String.valueOf(order.getBuyerId()))
                .userProfileImage(user.getProfileImage())
                .createdAt(LocalDateTime.now())
                .notificationType(NotificationType.NEW_ORDER)
                .seen(false)
                .build());

        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Status updated successfully " + newStatus)
                .build();
    }


    @Override
    public List<OrderProduct> searchOrdersByUsername(String username) {
        return orderProductRepository.findByUsernameContainingIgnoreCase(username);
    }

    @Override
    public Page<OrderResponse> getFarmerOrders(UUID farmerId, Pageable pageable) {
        Page<OrderProduct> orderPage = orderProductRepository.findAllOrdersForFarmerProducts(farmerId, pageable);
        return orderPage.map(orderProduct -> OrderResponse.builder()
                .orderId(orderProduct.getOrderId().toString())
                .phoneNumber(orderProduct.getPhoneNumber())
                .farmerId(orderProduct.getFarmerId())
                .pickUpDate(orderProduct.getPickUpDate())
                .paymentStatus(orderProduct.getPaymentStatus())
                .username(orderProduct.getUsername())
                .productName(orderProduct.getProductName())
                .productId(orderProduct.getProductId())
                .userEmail(orderProduct.getUserEmail())
                .amount(orderProduct.getAmount())
                .orderQuantity(orderProduct.getOrderQuantity())
                .shopName(orderProduct.getShopName())
                .status(orderProduct.getStatus())
                .location(orderProduct.getLocation())
                .createdAt(orderProduct.getCreatedAt())
                .updatedAt(orderProduct.getUpdatedAt())
                .build());
    }


    @Override
    public Page<OrderResponse> getPageableOrderById(UUID userId, Pageable pageable) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));

        Page<OrderProduct> orderProductsPage;

        orderProductsPage = orderProductRepository.findAllByBuyerId(userId, pageable);

        return orderProductsPage.map(orderProduct -> OrderResponse.builder()
                .orderId(orderProduct.getOrderId().toString())
                .phoneNumber(user.getPhone())
                .pickUpDate(orderProduct.getPickUpDate())
                .paymentStatus(orderProduct.getPaymentStatus())
                .username(orderProduct.getUsername())
                .status(orderProduct.getStatus())
                .location(orderProduct.getLocation())
                .createdAt(orderProduct.getCreatedAt())
                .updatedAt(orderProduct.getUpdatedAt())
                .orderQuantity(orderProduct.getOrderQuantity())
                .shopName(orderProduct.getShopName())
                .productName(orderProduct.getProductName())
                .productId(orderProduct.getProductId())
                .userEmail(orderProduct.getUserEmail())
                .amount(orderProduct.getAmount())
                .build());
    }


    public Page<OrderResponse> getPageableOrdersForSeller(UUID userId, Pageable pageable) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));

        Page<OrderProduct> orderProductsPage;

        orderProductsPage = orderProductRepository.findAllByFarmerId(userId, pageable);

        return orderProductsPage.map(orderProduct -> OrderResponse.builder()
                .orderId(orderProduct.getOrderId().toString())
                .phoneNumber(user.getPhone())
                .pickUpDate(orderProduct.getPickUpDate())
                .paymentStatus(orderProduct.getPaymentStatus())
                .username(orderProduct.getUsername())
                .status(orderProduct.getStatus())
                .location(orderProduct.getLocation())
                .createdAt(orderProduct.getCreatedAt())
                .updatedAt(orderProduct.getUpdatedAt())
                .orderQuantity(orderProduct.getOrderQuantity())
                .shopName(orderProduct.getShopName())
                .productName(orderProduct.getProductName())
                .productId(orderProduct.getProductId())
                .userEmail(orderProduct.getUserEmail())
                .amount(orderProduct.getAmount())
                .build());
    }




    @Override
    public NewOrdersCountDTOs getNewOrdersCount(UUID userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));

        // Time calculations
        LocalDateTime oneWeekAgo = LocalDateTime.now().minusWeeks(1);
        LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);

        long totalNewOrders, newOrdersPastWeek, newOrdersPastMonth, totalOrders;

        if (user.getRoleEnum().equals(RoleEnum.FARMER)) {
            totalNewOrders = orderProductRepository.countAllOrdersByFarmerId(userId, Status.NEW);
            newOrdersPastWeek = orderProductRepository.countAllOrdersByFarmerIdAndStatusAndCreatedAtAfter(userId,
                    Status.NEW, oneWeekAgo);
            newOrdersPastMonth = orderProductRepository.countAllOrdersByFarmerIdAndStatusAndCreatedAtAfter(userId,
                    Status.NEW, oneMonthAgo);
            totalOrders = orderProductRepository.countAllOrderByFarmerId(userId);
        } else if (user.getRoleEnum().equals(RoleEnum.BUYER)) {
            totalNewOrders = orderProductRepository.countByBuyerIdAndStatus(userId, Status.NEW);
            newOrdersPastWeek = orderProductRepository.countByBuyerIdAndStatusAndCreatedAtAfter(userId,
                    Status.NEW, oneWeekAgo);
            newOrdersPastMonth = orderProductRepository.countByBuyerIdAndStatusAndCreatedAtAfter(userId,
                    Status.NEW, oneMonthAgo);
            totalOrders = orderProductRepository.countByBuyerId(userId);
        } else {
            throw new NotFoundException("Unknown role: " + user.getRoleEnum());
        }

        double newOrdersPercentagePastMonth = totalOrders > 0
                ? ((double) newOrdersPastMonth / totalOrders) * 100
                : 0.0;

        NewOrdersCountDTOs newCount = new NewOrdersCountDTOs();
        newCount.setTotalNewOrders(totalNewOrders);
        newCount.setNewOrdersForThePastWeek(newOrdersPastWeek);
        newCount.setPercentOfNewOrdersWithinPastMonth(newOrdersPercentagePastMonth);

        return newCount;

    }



    // __________________________
    // counting all orders
    // _________________________
    @Override
    public CountAllOrders countAllOrders(UUID userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));

        // Time Calculations
        LocalDateTime oneWeekAgo = LocalDateTime.now().minusWeeks(1);
        LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);

        long totalOrders, ordersPastWeek, ordersPastMonth;

        if (user.getRoleEnum().equals(RoleEnum.FARMER)) {
            totalOrders = orderProductRepository.countAllOrderByFarmerId(userId);
            ordersPastWeek = orderProductRepository.countAllOrderMadeByBuyerIdAndCreatedAtAfter(userId, oneWeekAgo);
            ordersPastMonth = orderProductRepository.countAllOrderMadeByBuyerIdAndCreatedAtAfter(userId, oneMonthAgo);
        } else if (user.getRoleEnum().equals(RoleEnum.BUYER)) {
            totalOrders = orderProductRepository.countByBuyerId(userId);
            ordersPastWeek = orderProductRepository.countByBuyerIdAndCreatedAtAfter(userId, oneWeekAgo);
            ordersPastMonth = orderProductRepository.countByBuyerIdAndCreatedAtAfter(userId, oneMonthAgo);
        } else {
            throw new NotFoundException("Unknown role: " + user.getRoleEnum());
        }

        double ordersPercentagePastMonth = totalOrders > 0
                ? ((double) ordersPastMonth / totalOrders) * 100
                : 0.0;

        CountAllOrders countAllOrders = new CountAllOrders();
        countAllOrders.setTotalNumberOrders(totalOrders);
        countAllOrders.setOrdersForPastWeek(ordersPastWeek);
        countAllOrders.setOrdersPercentageForPastMonth(ordersPercentagePastMonth);

        return countAllOrders;
    }


    // COUNT ALL COMPLETED ORDERS
    public CountAllCompletedOrders countAllCompletedOrders(UUID userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found"));

        LocalDateTime oneWeekAgo = LocalDateTime.now().minusWeeks(1);
        LocalDateTime oneMonthAgo = LocalDateTime.now().minusMonths(1);

        long totalCompletedOrders, completedOrdersPastWeek, completedOrdersPastMonth;

        if (user.getRoleEnum().equals(RoleEnum.FARMER)) {
            totalCompletedOrders = orderProductRepository.countAllOrdersByFarmerId(userId, Status.COMPLETED);
            completedOrdersPastWeek = orderProductRepository.countAllOrdersByFarmerIdAndStatusAndCreatedAtAfter(userId,
                    Status.COMPLETED, oneWeekAgo);
            completedOrdersPastMonth = orderProductRepository.countAllOrdersByFarmerIdAndStatusAndCreatedAtAfter(userId,
                    Status.COMPLETED, oneMonthAgo);
        } else if (user.getRoleEnum().equals(RoleEnum.BUYER)) {
            totalCompletedOrders = orderProductRepository.countByBuyerIdAndStatus(userId, Status.COMPLETED);
            completedOrdersPastWeek = orderProductRepository.countByBuyerIdAndStatusAndCreatedAtAfter(userId,
                    Status.COMPLETED, oneWeekAgo);
            completedOrdersPastMonth = orderProductRepository.countByBuyerIdAndStatusAndCreatedAtAfter(userId,
                    Status.COMPLETED, oneMonthAgo);
        } else {
            throw new NotFoundException("Unknown role: " + user.getRoleEnum());
        }

        double completedOrdersPercentagePastMonth = totalCompletedOrders > 0
                ? ((double) completedOrdersPastMonth / totalCompletedOrders) * 100
                : 0.0;

        CountAllCompletedOrders completedOrders = new CountAllCompletedOrders();
        completedOrders.setTotalNumberOfCompletedOrders(totalCompletedOrders);
        completedOrders.setNumberOfCompletedOrdersForPastWeek(completedOrdersPastWeek);
        completedOrders.setNumberOfCompletedOrdersForPastMonth(completedOrdersPercentagePastMonth);

        return completedOrders;
    }

    @Override
    public List<OrderProduct> getOrderProductByStatus(UUID farmerId, Status status) {
        return orderProductRepository.findByFarmerIdAndStatus(farmerId, status);
    }
}
