package AgricHub.Services.UserServiceImpl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class GraphService {

     private final ProductServiceImpl productService;
     private final BuyerDashBordServiceIMPL buyerDashBordServiceIMPL;

}
