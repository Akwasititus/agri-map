package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.FarmerDTOs.ProductUpdateDTOWithoutImage;
import AgricHub.DTOs.FarmerDTOs.ProductsDTO;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.ProductResponse;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.Dashbord.ProductRating;
import AgricHub.Models.Dashbord.ProductRatingResponse;
import AgricHub.Models.User;
import AgricHub.Repositories.ProductRatingRepository;
import AgricHub.Repositories.ProductRepository;
import AgricHub.Repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl {

    private final ProductRepository productRepository;
    private final UserRepository userRepository;
    private final AwsS3Service awsS3Service;
    private final SingleFileUploadService singleFileUploadService;
    private final ProductRatingRepository productRatingRepository;

    public GenResponse addProduct(ProductsDTO product) throws IOException {
        Optional<User> isFarmer = userRepository.findById(UUID.fromString(product.getUserId()));
             Product newProduct = Product
                        .builder()
                        .name(product.getName())
                        .description(product.getDescription())
                        .productCategory(product.getProductCategory())
                        .productType(product.getProductType())
                        .amount(product.getAmount())
                     .productRate(product.getProductRate())
                     .orderQuantity(product.getOrderQuantity())
                        .quantity(product.getQuantity())
                        .userId(product.getUserId())
                     .imageKeyName(product.getImage().getOriginalFilename())
                        .imageUrl(awsS3Service.uploadFile(product.getImage().getOriginalFilename(),
                                product.getImage()).toString())
                        .createdAt(LocalDateTime.now())
                        .build();

             if (isFarmer.isPresent()) {
                 productRepository.save(newProduct);
             }


        return GenResponse
                .builder()
                .status(HttpStatus.CREATED.value())
                .message("Product Added Successfully!")
                .build();
    }

    public List<ProductResponse> getAllProducts() {
        List<Product> allProductList = productRepository.findAll();

        return allProductList.stream()
                .filter(product -> product.getQuantity() > 0)
                .map(product -> {
                    double averageRating = averageRating(product.getId());
                    return new ProductResponse(
                            product.getId(),
                            product.getName(),
                            product.getUserId(),
                            product.getDescription(),
                            product.getAmount(),
                            product.getQuantity(),
                            averageRating,
                            product.getImageUrl(),
                            product.getProductCategory(),
                            product.getProductType(),
                            product.getOrderQuantity(),
                            product.getType(),
                            product.getCreatedAt(),
                            product.getUpdatedAt()
                    );
                })
                .collect(Collectors.toList());
    }

    public List<Product> getAFarmersProducts(String userId) {
        List<Product> listOfProducts = productRepository.findAllByUserId(userId);

        return listOfProducts.stream()
                .filter(product -> product.getQuantity() > 0)
                .collect(Collectors.toList());
    }

    public GenResponse updateProduct(String id, ProductsDTO product) throws IOException {
        Optional<Product> isAvailable = productRepository.findById(UUID.fromString(id));

        if (isAvailable.isPresent()) {
            Product newProduct = Product
                .builder()
                .id(UUID.fromString(id))
                    .userId(isAvailable.get().getUserId())
                .name(product.getName())
                .description(product.getDescription())
                .productCategory(product.getProductCategory())
                .productType(product.getProductType())
                .amount(product.getAmount())
                .quantity(product.getQuantity())
                .imageKeyName(isAvailable.get().getImageKeyName().isBlank() ? isAvailable.get().getImageKeyName()
                        : product.getImage().getOriginalFilename())
                .imageUrl(isAvailable.get().getImageUrl().isBlank() ? isAvailable.get().getImageUrl()
                        : awsS3Service.uploadFile(product.getImage().getOriginalFilename(),
                        product.getImage()).toString())
                .updatedAt(LocalDateTime.now())
                .build();
                productRepository.save(newProduct);
            return GenResponse
                    .builder()
                    .status(HttpStatus.OK.value())
                    .message("Product Updated Successfully!")
                    .build();
        }
        throw new NotFoundException("Product Not Found!");
    }

    public List<Product> search(String productName) {
        List<Product> products = productRepository.findAll();

        return products.stream()
                .filter(product -> product.getName().toLowerCase().contains(productName.toLowerCase()))
                .toList();
    }

    public GenResponse deleteProduct(String id) {
         // Delete File for related file from S3 Bucket
         Optional<Product> product = productRepository.findById(UUID.fromString(id));

         if (product.isPresent()) {
             productRepository.save(
                     Product
                             .builder()
                             .id(product.get().getId())
                             .quantity(0)
                             .name(product.get().getName())
                             .userId(product.get().getUserId())
                             .productType(product.get().getProductType())
                             .imageKeyName(product.get().getImageKeyName())
                             .productCategory(product.get().getProductCategory())
                             .imageUrl(product.get().getImageUrl())
                             .description(product.get().getDescription())
                             .amount(product.get().getAmount())
                             .createdAt(product.get().getCreatedAt())
                             .deletedAt(LocalDateTime.now())
                             .build()
             );
             return GenResponse
                     .builder()
                     .status(HttpStatus.OK.value())
                     .message("Product Deleted Successfully!")
                     .build();
         }

         throw  new IllegalArgumentException("Product Not found!");

    }

    public Optional<Product> getAProducts(String id, String userId) {
        Optional<Product> product = productRepository.findById(UUID.fromString(id));

        if (Objects.equals(product.get().getUserId(), userId)) {
            return product;
        }

        throw new IllegalArgumentException("Product does not belong to user!");
    }

    public GenResponse updateAProduct(String id, ProductUpdateDTOWithoutImage product) {
        Optional<Product> isAvailable = productRepository.findById(UUID.fromString(id));

        if (isAvailable.isPresent()) {
            Product newProduct = Product
                    .builder()
                    .id(isAvailable.get().getId())
                    .userId(isAvailable.get().getUserId())
                    .name(product.getName())
                    .description(product.getDescription())
                    .productCategory(product.getProductCategory())
                    .productType(product.getProductType())
                    .amount(product.getAmount())
                    .imageUrl(isAvailable.get().getImageUrl())
                    .imageKeyName(isAvailable.get().getImageKeyName())
                    .quantity(product.getQuantity())
                    .updatedAt(LocalDateTime.now())
                    .build();
            productRepository.save(newProduct);
            return GenResponse
                    .builder()
                    .status(HttpStatus.OK.value())
                    .message("Product Updated Successfully!")
                    .build();
        }

        throw new IllegalArgumentException("Product Not Found!");
    }

    public GenResponse rateProduct(UUID userId, UUID productId, double rate, String comment) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("Buyer not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NotFoundException("product not found"));



        ProductRating productRate = new ProductRating();
        productRate.setProductId(product.getId());
        productRate.setUserId(user.getId());
        productRate.setComment(comment);
        productRate.setAverageRate(rate);
        productRate.setRate(rate);

        productRate.setRatedAt(LocalDateTime.now());

        productRatingRepository.save(productRate);

        return  GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message(product.getName() + " Rated")
                .build();
    }

    public List<ProductRatingResponse> getAllRatings(UUID productID) {
        // Fetch ratings only for the specified product
        List<ProductRating> ratings = productRatingRepository.findByProductId(productID);
        return ratings.stream()
                .map(this::convertToProductRatingResponse)
                .collect(Collectors.toList());
    }

    private ProductRatingResponse convertToProductRatingResponse(ProductRating rating) {

        User user = userRepository.findById(rating.getUserId())
                .orElseThrow(() -> new NotFoundException("User not found"));

        Product product = productRepository.findById(rating.getProductId())
                .orElseThrow(() -> new NotFoundException("Product not found"));

        double averageRating = averageRating(product.getId());

        ProductRatingResponse response = new ProductRatingResponse();
        response.setUsername(user.getFirstName() + " " + user.getLastName());
        response.setUserProfile(user.getProfileImage());
        response.setAverageRate(averageRating);
        response.setRate(rating.getRate());
        response.setComment(rating.getComment());
        response.setRatedAt(rating.getRatedAt());

        return response;
    }


    public double averageRating(UUID productId) {
        List<ProductRating> ratings = productRatingRepository.findByProductId(productId);
        if (ratings.isEmpty()) {
            return 0.0;
        }
        double sum = ratings.stream().mapToDouble(ProductRating::getAverageRate).sum();
        double average = sum / ratings.size();
        return Math.round(average * 10.0) / 10.0;
    }
}
