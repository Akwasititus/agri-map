package AgricHub.Services.UserServiceImpl;

import AgricHub.Configs.JwtService;
import AgricHub.DTOs.Login.LoginDTO;
import AgricHub.DTOs.ResponseDTOs.AuthTokenResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.EmailSendingException;
import AgricHub.Exception.InvalidTokenException;
import AgricHub.Exception.FailureException;
import AgricHub.Exception.NotFoundException;
import AgricHub.Exception.TokenExpiredException;
import AgricHub.Models.ForgotPasswords;
import AgricHub.Models.Token.Token;
import AgricHub.Models.Token.TokenRepository;
import AgricHub.Models.User;
import AgricHub.Repositories.ForgotPasswordRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.AuthService;
import AgricHub.Email.EmailTokenService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.UUID;
import java.util.ArrayList;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.TOKEN_EXPIRED;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.NOT_FOUND;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.TOKEN_NOT_FOUND;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.TOKEN_DOES_NOT_MATCH;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.USER_EMAIL_NOT_FOUND;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.ACCOUNT_ACTIVATION_SUCCESSFULLY;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.AUTH_SUCCESS;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.REQUEST_SENT;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.PASSWORD_HAS_BEEN_USED_BEFORE;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.NEW_PASSWORD_SET_SUCCESSFULLY;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.CODE_AND_USER_NOT_FOUND;
import static AgricHub.Services.URLBuilder.createURLWithParams;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    @Value("${frontend_url}")
    String frontendBaseUrl;

    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final UserRepository userRepository;
    private final TokenRepository tokenRepository;
    private final EmailTokenService emailTokenService;
    private final ForgotPasswordRepository forgotPasswordRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailTokenService emailService;



    //    authentication
    @Override
    public AuthTokenResponse login(LoginDTO loginDTO) {

        var existingUser = userRepository.findByEmail(loginDTO.getEmail().trim());
        if (existingUser.isEmpty()) {
            throw new NotFoundException("This email does not exist");
        }

        // Authenticate the user
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginDTO.getEmail(),
                        loginDTO.getPassword())
        );

        // Retrieve user details
        UserDetails userDetails = (UserDetails) auth.getPrincipal();

        // Find the corresponding user in the database
        User isUser = userRepository.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new NotFoundException(NOT_FOUND));


        Map<String, Object> claims = new HashMap<>();
        claims.put("userID", isUser.getId());
        claims.put("email", isUser.getEmail());
        claims.put("firstName", isUser.getFirstName());
        claims.put("lastName", isUser.getLastName());
        claims.put("phone", isUser.getPhone());
        claims.put("City", isUser.getCity());
        claims.put("shopName", isUser.getShopName());



        var jwtToken = jwtService.generateToken(claims, userDetails);
        var refreshToken = jwtService.buildRefreshToken(userDetails);

        // Return authentication success with tokens
        return AuthTokenResponse.builder()
                .token(jwtToken)
                .refreshToken(refreshToken)
                .message(AUTH_SUCCESS)
                .build();
    }


    // activating the user account
    @Override
    public GenResponse activateAccount(String token, String email) {

        // Fetch the token and associated user
        Token savedToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new NotFoundException(TOKEN_NOT_FOUND));

        // Fetch the user by email
        User emailUser = userRepository.findByEmail(email)
                .orElseThrow(() -> new NotFoundException(USER_EMAIL_NOT_FOUND));

        // Check if the token has expired
        if (LocalDateTime.now().isAfter(savedToken.getExpiresAt())) {
           // sendValidationEmail(savedToken.getUser());
            throw new TokenExpiredException(TOKEN_EXPIRED);
        }

        // Validate if the user associated with the token does not match the user retrieved by email
        if (!savedToken.getUser().getId().equals(emailUser.getId())) {
            throw new InvalidTokenException(TOKEN_DOES_NOT_MATCH);
        }

        // Activate the user account
        emailUser.setEnabled(true);
        userRepository.save(emailUser);

        // Update the token validation timestamp
        savedToken.setValidatedAt(LocalDateTime.now());
        tokenRepository.save(savedToken);

        // Return the response
        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message(ACCOUNT_ACTIVATION_SUCCESSFULLY)
                .build();
    }



    @Override
    public void refreshToken(
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse
    ) throws IOException {
        final String authorization = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION);
        final String refreshToken;
        final String userEmail;

        if (authorization == null || !authorization.startsWith("Bearer ")) {
            return;
        }

        refreshToken = authorization.substring(7);
        userEmail = jwtService.extractUsername(refreshToken);

        if (userEmail != null) {
            var user = userRepository.findByEmail(userEmail)
                    .orElseThrow(() -> new NotFoundException(NOT_FOUND));

            if (jwtService.isTokenValid(refreshToken, user)) {
                var token = jwtService.generateToken(user);
                var authResponse = AuthTokenResponse.builder()
                        .token(token)
                        .message(AUTH_SUCCESS)
                        .refreshToken(refreshToken)
                        .build();

                // Serialize AuthTokenResponse to JSON
                ObjectMapper objectMapper = new ObjectMapper();
                String jsonResponse = objectMapper.writeValueAsString(authResponse);

                // Write the JSON response
                httpServletResponse.setContentType("application/json");
                httpServletResponse.setCharacterEncoding("UTF-8");
                httpServletResponse.getWriter().write(jsonResponse);
            }
        }
    }

    @Override
    public GenResponse resendActivationCode(String token, String email) {

        // Fetch the token and associated user
        Token savedToken = tokenRepository.findByToken(token)
                .orElseThrow(() -> new NotFoundException(TOKEN_NOT_FOUND));

        // Fetch the user by email
      User isUser =  userRepository.findByEmail(email)
                .orElseThrow(() -> new NotFoundException(USER_EMAIL_NOT_FOUND));

        // Resend the validation email
        try {
            // Call sendValidationEmail method from EmailTokenService
            emailTokenService.sendValidationEmail(savedToken.getUser());
        } catch (MessagingException e) {
            throw new EmailSendingException("Error sending Activation Code", e);
        }
        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Activation code sent successfully to " + isUser.getEmail())
                .build();
    }



    public String generateEmailVerificationToken() {
        return UUID.randomUUID().toString();
    }

    // Forgot Password
    public GenResponse forgotPassword(ForgotPasswords requestData)
            throws UnsupportedEncodingException, MessagingException {

        Optional<User> validUser = userRepository.findByEmail(requestData.getEmail());

        if (validUser.isEmpty()) {
            throw new NotFoundException("This user does not exist!");
        }

        String code = generateEmailVerificationToken();

        forgotPasswordRepository.save(ForgotPasswords
                .builder()
                .code(code)
                .email(requestData.getEmail())
                .build());

        // Construct the URL using the service name registered in Eureka

        List<Map.Entry<String, String>> params = new ArrayList<>();
        params.add(new AbstractMap.SimpleEntry<>("email", validUser.get().getEmail()));
        params.add(new AbstractMap.SimpleEntry<>("code", code));


        emailService.sendResetPasswordEmail(validUser, createURLWithParams(
                frontendBaseUrl + "/auth/account-recovery", params));

        return GenResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message(REQUEST_SENT).build();
    }


    public GenResponse verifyForgotPassword(ForgotPasswords forgotPasswordBody, HttpServletRequest requestObject) {
        // Validate the verification code
        ForgotPasswords isValid = forgotPasswordRepository.findByCode(forgotPasswordBody.getCode());
        Optional<User> validateUser = userRepository.findByEmail(forgotPasswordBody.getEmail());

        if (forgotPasswordBody.getNewPassword().isEmpty()) {
            throw new FailureException("New Password field cannot be null!");
        }

        if (isValid != null && validateUser.isPresent()) {
            User userToUpdate = validateUser.get();

            // Check if the new password has been used before
            List<ForgotPasswords> passwordHistory = forgotPasswordRepository.findByEmail(forgotPasswordBody.getEmail());
            for (ForgotPasswords record : passwordHistory) {
                if (passwordEncoder.matches(forgotPasswordBody.getNewPassword(), record.getOldPassword())) {
                    return GenResponse.builder()
                            .status(HttpStatus.CONFLICT.value())
                            .message(PASSWORD_HAS_BEEN_USED_BEFORE).build();
                }
            }

            if (passwordEncoder.matches(forgotPasswordBody.getNewPassword(), validateUser.get().getPassword())) {
                return GenResponse.builder()
                        .status(HttpStatus.CONFLICT.value())
                        .message(PASSWORD_HAS_BEEN_USED_BEFORE).build();
            }

            // Update the password
            String newPassword = passwordEncoder.encode(forgotPasswordBody.getNewPassword());

            forgotPasswordRepository.save(ForgotPasswords
                    .builder()
                            .id(isValid.getId())
                            .newPassword("Completed!")
                            .oldPassword(newPassword)
                    .build());
            userRepository.save(User
                    .builder()
                            .id(validateUser.get().getId())
                            .email(validateUser.get().getEmail())
                            .phone(validateUser.get().getPhone())
                            .productType(validateUser.get().getProductType())
                            .accountLocked(validateUser.get().isAccountLocked())
                            .firstName(validateUser.get().getFirstName())
                            .lastName(validateUser.get().getLastName())
                            .cart(validateUser.get().getCart())
                            .shopName(validateUser.get().getShopName())
                            .createdAt(validateUser.get().getCreatedAt())
                            .lastModifiedAt(LocalDateTime.now())
                            .enabled(validateUser.get().isEnabled())
                            .city(validateUser.get().getCity())
                            .roleEnum(validateUser.get().getRoleEnum())
                            .password(newPassword)
                    .build());

            return GenResponse.builder()
                    .status(HttpStatus.OK.value())
                    .message(NEW_PASSWORD_SET_SUCCESSFULLY).build();
        }
        return GenResponse.builder()
                .status(HttpStatus.NOT_FOUND.value())
                .message(CODE_AND_USER_NOT_FOUND).build();
    }


}
