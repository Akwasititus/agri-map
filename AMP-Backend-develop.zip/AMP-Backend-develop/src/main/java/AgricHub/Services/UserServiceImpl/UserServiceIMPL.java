package AgricHub.Services.UserServiceImpl;


import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.ShopRatingsResponse;
import AgricHub.DTOs.ResponseDTOs.ShopResponse;
import AgricHub.DTOs.ResponseDTOs.UserResponseRequest;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import AgricHub.Models.Dashbord.Rating;
import AgricHub.Models.Roles.RoleEnum;
import AgricHub.Models.User;
import AgricHub.Repositories.FarmerBusinessProfileRepository;
import AgricHub.Repositories.RatingRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.UserService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Service
@RequiredArgsConstructor
public class UserServiceIMPL implements UserService {

    private final UserRepository userRepository;
    private final FarmerBusinessProfileRepository farmerBusinessProfileRepository;
    private final RatingRepository ratingRepository;


    @Transactional
    @Override
    public UserResponseRequest getUserDetails(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found"));

        return UserResponseRequest.builder()
                .id(user.getId())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .email(user.getEmail())
                .phone(user.getPhone())
                .businessID(user.getBusinessID())
                .subAccountCode(user.getSubAccountCode())
                .location(user.getCity())
                .organizationName(user.getShopName())
                .profileImage(user.getProfileImage())
                .role(user.getRoleEnum())
                .build();
    }



    public List<ShopResponse> getAllSellers() {

        List<User> farmers = userRepository.findByRoleEnum(RoleEnum.FARMER);

            // Fetch business profiles for the farmers
            List<ShopResponse> shopResponses = new ArrayList<>();

            for (User farmer : farmers) {
                // Retrieve the business profile using the businessID from the farmer
                Optional<FarmerBusinessProfile> profile = farmerBusinessProfileRepository
                        .findByBusinessID(farmer.getBusinessID());

                if (profile.isPresent()) {

                    UUID sellerId = farmer.getId();
                    double averageRating = getAverageRating(farmer.getId());
                    List<Rating> ratings = ratingRepository.findBySellerId(sellerId);

                    List<ShopRatingsResponse> ratingResponses = ratings.stream()
                            .map(rating -> {
                                User buyer = userRepository.findById(rating.getBuyerId())
                                        .orElseThrow(() -> new NotFoundException("Buyer not found"));

                                return ShopRatingsResponse.builder()
                                        .buyerId(rating.getBuyerId())
                                        .rate(rating.getRate())
                                        .comment(rating.getComment())
                                        .username(buyer.getFirstName() + " " + buyer.getLastName())
                                        .userProfile(buyer.getProfileImage())
                                        .ratedAt(rating.getRatedAt())
                                        .build();
                            })
                            .toList();

                    ShopResponse shopResponse = ShopResponse.builder()
                            .businessName(farmer.getShopName())
                            .businessID(profile.get().getBusinessID())
                            .sellerId(farmer.getId())
                            .businessContact(profile.get().getBusinessContact())
                            .businessEmail(profile.get().getBusinessEmail())
                            .businessWebsiteUrl(profile.get().getBusinessWebsiteUrl())
                            .businessSocialMediaLinks(profile.get().getBusinessSocialMediaLinks())
                            .businessCountryLocation(profile.get().getBusinessCountryLocation())
                            .businessRegionLocation(profile.get().getBusinessRegionLocation())
                            .aboutUs(profile.get().getAboutUs())
                            .businessLogo(profile.get().getBusinessLogo())
                            .businessGallery(profile.get().getBusinessGallery())
                            .businessVision(profile.get().getBusinessVision())
                            .businessMission(profile.get().getBusinessMission())
                            .businessProductsProduced(profile.get().getBusinessProductsProduced())
                            .businessFarmingPractice(profile.get().getBusinessFarmingPractice())
                            .shopOwner(farmer.getFirstName() + " " + farmer.getLastName())
                            .rate(averageRating)
                            .allRatings(ratingResponses)
                            .build();
                    shopResponses.add(shopResponse);
                }
            }
            return shopResponses;
    }



    @Override
    public GenResponse rateShop(UUID sellerId, UUID buyerId, double rate, String comment) {
        User seller = userRepository.findById(sellerId)
                .orElseThrow(() -> new NotFoundException("Seller not found"));
        User buyer = userRepository.findById(buyerId)
                .orElseThrow(() -> new NotFoundException("Buyer not found"));

        Rating rating = new Rating();
        rating.setSellerId(seller.getId());
        rating.setBuyerId(buyer.getId());
        rating.setRate(rate);
        rating.setComment(comment);
        rating.setRatedAt(LocalDateTime.now());

        ratingRepository.save(rating);

      return  GenResponse.builder()
              .status(HttpStatus.OK.value())
              .message(seller.getFirstName() + " " + seller.getLastName() + " Rated " + rate)
              .build();
    }


    private double getAverageRating(UUID sellerId) {
        List<Rating> ratings = ratingRepository.findBySellerId(sellerId);
        if (ratings.isEmpty()) {
            return 0.0;
        }
        double sum = ratings.stream().mapToDouble(Rating::getRate).sum();
        double average = sum / ratings.size();
        return Math.round(average * 10.0) / 10.0;
    }






}
