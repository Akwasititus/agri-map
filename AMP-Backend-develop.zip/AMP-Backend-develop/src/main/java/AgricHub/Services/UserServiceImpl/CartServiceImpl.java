package AgricHub.Services.UserServiceImpl;

import AgricHub.DTOs.FarmerDTOs.ProductsDTO;
import AgricHub.DTOs.FarmerDTOs.UpdateCartItemRequest;
import AgricHub.DTOs.ResponseDTOs.CartProductsResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.NotFoundException;
import AgricHub.Exception.UserAlreadyExist;
import AgricHub.Models.Dashbord.Cart;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.User;
import AgricHub.Repositories.CartRepository;
import AgricHub.Repositories.ProductRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.CartService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import static AgricHub.DTOs.ResponseDTOs.ResponseConstants.NOT_FOUND;


@Service
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;


    @Transactional
    public GenResponse addProductToCart(UUID userId, UUID productId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NotFoundException("Product not found"));

        Cart cart = user.getCart();
        if (cart == null) {
            cart = new Cart();
            user.setCart(cart);
        }

        if (cart.getProducts().stream().anyMatch(p -> p.getId().equals(productId))) {
            throw new UserAlreadyExist("Product already added in Cart");
        }

        cart.getProducts().add(product);
        cart.updateTotalPrice();
        cart.getProductCount();
        userRepository.save(user);

        return GenResponse.builder()
                .status(HttpStatus.CREATED.value())
                .message("Product added to cart")
                .build();
    }



    @Override
    @Transactional
    public GenResponse removeProductFromCart(UUID userId, UUID productId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException(NOT_FOUND));

        Cart cart = user.getCart();
        if (cart == null) {
            throw new NotFoundException("Cart not found for user");
        }

        Product productToRemove = cart.getProducts().stream()
                .filter(p -> p.getId().equals(productId))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Product not found in cart"));

        cart.getProducts().remove(productToRemove);
        cart.updateTotalPrice();
        cart.getProductCount();

        userRepository.save(user);

        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Product removed from cart")
                .build();
    }

    @Override
    public CartProductsResponse getCartProducts(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException(NOT_FOUND));

        Cart cart = user.getCart();
        if (cart == null) {
            return new CartProductsResponse(new ArrayList<>(), 0.0, user.getEmail(), 0.0);
        }

        List<ProductsDTO> productDTOs = cart.getProducts().stream()
                .map(this::convertToProductDTO)
                .collect(Collectors.toList());

        return new CartProductsResponse(productDTOs, 0.0, user.getEmail(), 0.0);
    }

    private ProductsDTO convertToProductDTO(Product product) {
        return ProductsDTO.builder()
                .id(product.getId())
                .userId(product.getUserId())
                .quantity(product.getQuantity())
                .orderQuantity(product.getOrderQuantity())
                .imageKeyName(product.getImageKeyName())
                .productCategory(product.getProductCategory())
                .productType(product.getProductType())
                .imageUrl(product.getImageUrl())
                .name(product.getName())
                .description(product.getDescription())
                .amount(product.getAmount())
                .imageUrl(product.getImageUrl())
                .build();
    }

    @Override
    public GenResponse updateProductQuantity(UpdateCartItemRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new NotFoundException("User not found"));

        Cart cart = user.getCart();
        if (cart == null) {
            throw new NotFoundException("Cart not found for user");
        }

        Product productToUpdate = cart.getProducts().stream()
                .filter(p -> p.getId().equals(request.getProductId()))
                .findFirst()
                .orElseThrow(() -> new NotFoundException("Product not found in cart"));
        productToUpdate.setOrderQuantity(request.getQuantity());


        cartRepository.save(cart);

        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Product quantity updated in cart")
                .build();
    }

    @Override
    @Transactional
    public GenResponse clearCart(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException(NOT_FOUND));

        Cart cart = user.getCart();
        if (cart == null) {
            throw new NotFoundException("Cart not found for user");
        }

        cart.getProducts().removeAll(cart.getProducts());
        cart.updateTotalPrice();
        cart.getProductCount();

        cartRepository.save(cart);

        return GenResponse.builder()
                .status(HttpStatus.OK.value())
                .message("Cart cleared successfully")
                .build();
    }

}
