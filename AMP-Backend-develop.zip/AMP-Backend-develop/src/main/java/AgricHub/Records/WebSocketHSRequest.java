package AgricHub.Records;

public record WebSocketHSRequest(String socketId, String userId) {
}
