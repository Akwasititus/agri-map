package AgricHub.ValidationCheck.SingleCharactorCheck;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class NotSingleCharacterValidator implements ConstraintValidator<NotSingleCharacter, String> {

    @Override
    public void initialize(NotSingleCharacter constraintAnnotation) {
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value == null || value.trim().length() > 1;
    }
}

