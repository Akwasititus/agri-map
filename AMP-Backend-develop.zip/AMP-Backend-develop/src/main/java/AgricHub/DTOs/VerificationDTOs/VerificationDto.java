
package AgricHub.DTOs.VerificationDTOs;

public record VerificationDto(String email, String code) {
}
