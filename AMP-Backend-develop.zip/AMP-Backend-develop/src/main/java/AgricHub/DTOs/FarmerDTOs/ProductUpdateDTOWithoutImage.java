package AgricHub.DTOs.FarmerDTOs;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class ProductUpdateDTOWithoutImage {

    private UUID id;
    private String userId;
    private String name;
    private String description;
    private double amount;
    private double quantity;
    private String imageUrl;
    private String imageKeyName;
    private String productCategory;
    private String productType;
}
