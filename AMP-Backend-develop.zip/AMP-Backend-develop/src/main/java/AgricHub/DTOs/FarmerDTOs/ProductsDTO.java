package AgricHub.DTOs.FarmerDTOs;

import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ProductsDTO {


    private UUID id;
    private String userId;
    private String name;
    private String description;
    private double amount;
    @Builder.Default
    private double quantity = 1;
    private double productRate;
    private String imageUrl;
    private int orderQuantity;
    private String imageKeyName;
    private MultipartFile image;
    private String productCategory;
    private String productType;


}
