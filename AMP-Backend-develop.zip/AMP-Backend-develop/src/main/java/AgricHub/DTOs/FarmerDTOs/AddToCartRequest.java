package AgricHub.DTOs.FarmerDTOs;

import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Data
@Builder
public class AddToCartRequest {
    private UUID userId;
    private UUID productId;
}
