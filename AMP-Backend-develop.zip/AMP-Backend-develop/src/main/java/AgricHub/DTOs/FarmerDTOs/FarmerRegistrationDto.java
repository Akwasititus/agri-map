package AgricHub.DTOs.FarmerDTOs;


import AgricHub.ValidationCheck.SingleCharactorCheck.NotSingleCharacter;
import AgricHub.ValidationCheck.Email.ValidEmail;
import AgricHub.ValidationCheck.Password.ValidPassword;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;

import java.util.UUID;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class FarmerRegistrationDto {

    @NotEmpty(message = "firstName is required")
    @NotBlank(message = "firstName is required")
    @NotSingleCharacter
    private String firstName;

    @NotEmpty(message = "lastName is required")
    @NotBlank(message = "lastName is required")
    @NotSingleCharacter
    private String lastName;

    @Column(unique = true)
    @ValidEmail
    @NotEmpty(message = "email field is required")
    @NotBlank(message = "email field is required")
    private String email;

    @NotEmpty(message = "password is required")
    @NotBlank(message = "password is required")
    @ValidPassword
    private String password;

    @NotEmpty(message = "phone is required")
    @NotBlank(message = "phone is required")
    @NotSingleCharacter
    private String phone;

    @NotEmpty(message = "shopName is required")
    @NotBlank(message = "shopName is required")
    @NotSingleCharacter
    private String shopName;

    @NotEmpty(message = "country is required")
    @NotBlank(message = "country is required")
    @NotSingleCharacter
    private String country;

    @NotEmpty(message = "region is required")
    @NotBlank(message = "region is required")
    @NotSingleCharacter
    private String region;

    @NotEmpty(message = "city is required")
    @NotBlank(message = "city is required")
    @NotSingleCharacter
    private String city;

    @NotEmpty(message = " settlement_bank required")
    @NotBlank(message = "settlement_bank is required")
    @NotSingleCharacter
    @JsonProperty("settlement_bank")
    private String settlementBank;

    @NotEmpty(message = "account_number is required")
    @NotBlank(message = "account_number is required")
    @NotSingleCharacter
    @JsonProperty("account_number")
    private String accountNumber;


    private String profileImage;
    private UUID businessID;


}
