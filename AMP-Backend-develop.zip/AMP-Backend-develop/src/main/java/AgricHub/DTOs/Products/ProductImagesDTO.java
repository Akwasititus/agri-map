package AgricHub.DTOs.Products;

import lombok.Builder;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
@Builder
public class ProductImagesDTO {

    private MultipartFile file;
    private String productId;

}
