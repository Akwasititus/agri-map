package AgricHub.DTOs.Products;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ProductDTOs {


    private UUID productID;
    private String productName;
    private String productDescription;
    private int productPrice;
    private double productQuantity;
    private String productCategory;
    private String productImage;

}
