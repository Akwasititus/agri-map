package AgricHub.DTOs.CountOrders;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class NewOrdersCountDTOs {
    private long totalNewOrders;
    private long newOrdersForThePastWeek;
    private double percentOfNewOrdersWithinPastMonth;
}
