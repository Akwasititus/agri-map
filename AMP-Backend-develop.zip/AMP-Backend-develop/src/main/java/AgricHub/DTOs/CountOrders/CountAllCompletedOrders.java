package AgricHub.DTOs.CountOrders;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CountAllCompletedOrders {

    private long totalNumberOfCompletedOrders;
    private long numberOfCompletedOrdersForPastWeek;
    private double numberOfCompletedOrdersForPastMonth;
}
