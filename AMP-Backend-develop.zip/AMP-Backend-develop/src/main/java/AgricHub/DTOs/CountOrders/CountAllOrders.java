package AgricHub.DTOs.CountOrders;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CountAllOrders {

    private long totalNumberOrders;
    private long ordersForPastWeek;
    private double ordersPercentageForPastMonth;
}
