package AgricHub.DTOs.ResponseDTOs;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class FarmerProfileResponses {

    private String businessName;

    private String businessEmail;

    private String businessContact;

    private String businessWebsiteUrl;

    private String businessSocialMediaLinks;

    private String businessCityLocation;

    private String businessCountryLocation;

    private String businessRegionLocation;

    private String aboutUs;

    private String businessLogo;

    private String businessVision;

    private String businessMission;

    private String businessProductsProduced;

    private String businessFarmingPractice;
}











