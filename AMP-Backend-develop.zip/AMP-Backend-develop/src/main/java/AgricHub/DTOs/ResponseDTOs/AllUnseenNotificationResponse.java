package AgricHub.DTOs.ResponseDTOs;

import AgricHub.Models.Dashbord.Notification;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@Builder
public class AllUnseenNotificationResponse {

    private int status;
    private String message;
    private List<Notification> notifications;

}
