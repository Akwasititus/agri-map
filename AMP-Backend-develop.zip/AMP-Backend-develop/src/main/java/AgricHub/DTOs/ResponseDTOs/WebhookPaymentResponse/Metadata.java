package AgricHub.DTOs.ResponseDTOs.WebhookPaymentResponse;

import lombok.Data;

@Data
public class Metadata { //

    public String orderId;
    public String buyerId;
    public String subaccount;

}
