package AgricHub.DTOs.ResponseDTOs;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BanksResponses {

    @JsonProperty("bank_name")
    private String bankName;

    @JsonProperty("bank_code")
    private String bankCode;
}
