package AgricHub.DTOs.ResponseDTOs.InitializationResponse;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthData {
    @JsonProperty("authorization_url")
    private String authorizationURL;
    @JsonProperty("access_code")
    private String accessCode;
    private String reference;
}
