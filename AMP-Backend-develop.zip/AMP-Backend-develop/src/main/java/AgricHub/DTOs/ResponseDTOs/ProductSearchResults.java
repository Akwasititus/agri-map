package AgricHub.DTOs.ResponseDTOs;

import AgricHub.Models.Dashbord.Product;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductSearchResults {

    private String message;
    private int length;
    private List<Product> results;

}
