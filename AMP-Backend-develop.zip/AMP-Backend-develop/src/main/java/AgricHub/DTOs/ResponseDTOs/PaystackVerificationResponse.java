package AgricHub.DTOs.ResponseDTOs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class PaystackVerificationResponse {
    private boolean status;
    private String message;
    private TransactionData data;


    @Data
    public static class TransactionData {
        private long id;
        private String domain;
        private String status;
        private String reference;
        private int amount;
        private String message;
        @JsonProperty("gateway_response")
        private String gatewayResponse;
        @JsonProperty("paid_at")
        private String paidAt;
        @JsonProperty("created_at")
        private String createdAt;
        private String channel;
        private String currency;
        @JsonProperty("ip_address")
        private String ipAddress;
        private Object metadata;
        private Object log;
        private int fees;
        @JsonProperty("fees_split")
        private Object feesSplit;
        private Authorization authorization;
        private Customer customer;
        private Object plan;
        private Object split;
        @JsonProperty("order_id")
        private Object orderId;
        @JsonProperty("requested_amount")
        private int requestedAmount;
        @JsonProperty("pos_transaction_data")
        private Object posTransactionData;
        private Object source;
        @JsonProperty("fees_breakdown")
        private Object feesBreakdown;
        @JsonProperty("transaction_date")
        private String transactionDate;
        @JsonProperty("plan_object")
        private Object planObject;
        private Object subaccount;

    }

    @Data
    public static class Authorization {
        @JsonProperty("authorization_code")
        private String authorizationCode;
        private String bin;
        private String last4;
        @JsonProperty("exp_month")
        private String expMonth;
        @JsonProperty("exp_year")
        private String expYear;
        private String channel;
        @JsonProperty("card_type")
        private String cardType;
        private String bank;
        @JsonProperty("country_code")
        private String countryCode;
        private String brand;
        private boolean reusable;
        private String signature;
        @JsonProperty("account_name")
        private String accountName;


    }

    @Data
    public static class Customer {
        private long id;
        @JsonProperty("first_name")
        private String firstName;
        @JsonProperty("last_name")
        private String lastName;
        private String email;
        @JsonProperty("customer_code")
        private String customerCode;
        private String phone;
        private Object metadata;
        @JsonProperty("risk_action")
        private String riskAction;
    }
}
