package AgricHub.DTOs.ResponseDTOs;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProfileUpdateResponse {

    private int status;
    private String message;
    private UpdatedUserInfoDTO data;
}
