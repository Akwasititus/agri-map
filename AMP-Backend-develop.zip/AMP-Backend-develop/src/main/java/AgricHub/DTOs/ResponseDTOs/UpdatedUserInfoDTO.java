package AgricHub.DTOs.ResponseDTOs;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UpdatedUserInfoDTO {

    private String firstName;
    private String lastName;
    private String phone;
    private String organizationName;
    private String profileImage;
}
