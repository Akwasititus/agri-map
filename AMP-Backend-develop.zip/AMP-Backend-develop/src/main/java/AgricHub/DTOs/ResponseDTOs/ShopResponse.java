package AgricHub.DTOs.ResponseDTOs;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.UUID;

@Builder
@Data
public class ShopResponse {
    private UUID businessID;
    private UUID sellerId;
    private String businessName;
    private String businessEmail;
    private String businessContact;
    private String businessWebsiteUrl;
    private List<String> businessSocialMediaLinks;
    private String businessCountryLocation;
    private String businessRegionLocation;
    private String aboutUs;
    private String businessLogo;
    private List<String> businessGallery;
    private String businessVision;
    private String businessMission;
    private String shopOwner;
    private List<String> businessProductsProduced;
    private List<String> businessFarmingPractice;
    private double rate;
    private List<ShopRatingsResponse> allRatings;
}
