
package AgricHub.DTOs.ResponseDTOs;
import AgricHub.DTOs.FarmerDTOs.ProductsDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.util.List;

@Data
@AllArgsConstructor
public class CartProductsResponse {
    private List<ProductsDTO> products;
    private double totalPrice;
    private String userEmail;
    private double productCount;
}
