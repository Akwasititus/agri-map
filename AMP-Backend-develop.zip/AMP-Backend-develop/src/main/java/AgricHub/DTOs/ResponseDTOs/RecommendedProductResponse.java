package AgricHub.DTOs.ResponseDTOs;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import lombok.NoArgsConstructor;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecommendedProductResponse {
    private  String productName;
    private  double productAmount;
}
