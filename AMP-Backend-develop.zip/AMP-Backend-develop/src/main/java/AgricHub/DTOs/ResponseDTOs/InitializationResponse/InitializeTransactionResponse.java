package AgricHub.DTOs.ResponseDTOs.InitializationResponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InitializeTransactionResponse {
    private boolean status;
    private String message;
    private AuthData data;
}
