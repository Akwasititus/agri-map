package AgricHub.DTOs.ResponseDTOs.WebhookPaymentResponse;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WebhookPaymentSuccessResponse {
    private String event;
    private WebhookPaymentSuccessData data;
}
