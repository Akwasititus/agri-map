package AgricHub.DTOs.ResponseDTOs.WebhookPaymentResponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WebhookPaymentSuccessData {
    private String domain;
    private String status;
    private String reference;
    private double amount;
    private String message;
    private Metadata metadata;




}

