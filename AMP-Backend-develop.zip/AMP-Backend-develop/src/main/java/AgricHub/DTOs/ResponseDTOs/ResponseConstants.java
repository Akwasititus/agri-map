
package AgricHub.DTOs.ResponseDTOs;

public final class ResponseConstants {

    public static final String SIGN_UP_SUCCESS = "Signed up successfully, check your inbox for  email verification.";
    public static final String AUTH_SUCCESS = "Log-in successful";
    public static final String ACCOUNT_ACTIVATION_SUCCESSFULLY = "Account Activated Successfully," +
            " please proceed to login!";
    public static final String TOKEN_NOT_FOUND = "The verification code was not found";
    public static final String TOKEN_EXPIRED = "The verification code has expired";
    public static final String NOT_FOUND = "User not found!";
    public static final String USER_ALREADY_EXIST = "Email address already in use";
    public static final String USER_EMAIL_NOT_FOUND = "User email not found!";
    public static final String TOKEN_DOES_NOT_MATCH = "The provided token does not match" +
            " the user associated with the email.";
    public static final String REQUEST_SENT = "Request Sent Successfully";
    public static final String PASSWORD_HAS_BEEN_USED_BEFORE = "This Password has been used before!";
    public static final String NEW_PASSWORD_SET_SUCCESSFULLY = "New password set successfully!";
    public static final String CODE_AND_USER_NOT_FOUND = "Code and User not found!";
}
