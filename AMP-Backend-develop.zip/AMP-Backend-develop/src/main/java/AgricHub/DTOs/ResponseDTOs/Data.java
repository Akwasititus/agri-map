package AgricHub.DTOs.ResponseDTOs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Data {
    private String id;
    private String domain;
    private String message;
    @JsonProperty("gateway_response")
    private String gatewayResponse;
    @JsonProperty("paid_at")
    private String paidAt;
    @JsonProperty("created_at")
    private String createdAt;
    private String fees;
    private double amount;
    private String currency;
    private String status;
    @JsonProperty("transaction_date")
    private String transactionDate;
    private String reference;
}
