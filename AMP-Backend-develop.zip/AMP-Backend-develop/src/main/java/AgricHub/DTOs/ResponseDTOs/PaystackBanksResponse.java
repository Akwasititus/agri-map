package AgricHub.DTOs.ResponseDTOs;

import lombok.Data;

import java.util.List;

@Data
public class PaystackBanksResponse {
    private boolean status;
    private String message;
    private List<Bank> data;

    @Data
    public static class Bank {
        private String name;
        private String code;
    }
}






