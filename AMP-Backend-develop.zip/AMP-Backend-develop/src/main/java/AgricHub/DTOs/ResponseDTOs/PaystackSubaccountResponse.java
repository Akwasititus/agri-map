package AgricHub.DTOs.ResponseDTOs;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PaystackSubaccountResponse {
    private boolean status;
    private String message;
    private SubaccountData data;

    @Data
    public static class SubaccountData {

        @JsonProperty("business_name")
        private String businessName;

        @JsonProperty("account_number")
        private String accountNumber;

        @JsonProperty("percentage_charge")
        private int percentageCharge;

        @JsonProperty("settlement_bank")
        private String settlementBank;

        @JsonProperty("account_name")
        private String accountName;

        @JsonProperty("subaccount_code")
        private String subAccountCode;
    }
}
