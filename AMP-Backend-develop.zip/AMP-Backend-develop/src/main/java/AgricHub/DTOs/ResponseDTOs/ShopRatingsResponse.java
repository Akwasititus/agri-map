package AgricHub.DTOs.ResponseDTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ShopRatingsResponse {
    private UUID buyerId;
    private double rate;
    private String comment;
    private String username;
    private String userProfile;
    private LocalDateTime ratedAt;
}
