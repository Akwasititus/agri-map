package AgricHub.DTOs.ResponseDTOs;

import AgricHub.Models.Dashbord.PaymentStatus;
import AgricHub.Models.Dashbord.Status;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@Builder
public class OrderResponse {

    private String orderId;
    private String username;
    private String location;
    private String phoneNumber;
    private UUID farmerId;

    private String productName;
    private UUID productId;

    private int orderQuantity;
    private String shopName;
    private double productQuantity;

    private String userEmail;
    private double amount;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime pickUpDate;
    private Status status;

    private PaymentStatus paymentStatus;
}
