package AgricHub.DTOs.ResponseDTOs;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductResponse {
    private UUID id;
    private String name;
    private String userId;
    private String description;
    private double amount;
    private double quantity;
    private double averageRating;
    private String imageUrl;
    private String productCategory;
    private String productType;
    private int orderQuantity;
    private String type;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
