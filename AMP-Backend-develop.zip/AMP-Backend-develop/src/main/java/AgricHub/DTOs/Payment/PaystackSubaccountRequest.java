package AgricHub.DTOs.Payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PaystackSubaccountRequest {

    @JsonProperty("business_name")
    private String businessName;

    @JsonProperty("settlement_bank")
    private String settlementBank;

    @JsonProperty("account_number")
    private String accountNumber;

    @JsonProperty("percentage_charge")
    private int percentageCharge;
}




