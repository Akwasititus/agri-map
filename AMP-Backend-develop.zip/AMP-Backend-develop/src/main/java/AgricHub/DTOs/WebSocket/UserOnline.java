package AgricHub.DTOs.WebSocket;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserOnline {

    private String userId;
    private boolean isOnline;

}
