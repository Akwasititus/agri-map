package AgricHub.DTOs.WebSocket;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ChatDTO {

    private List<ChatsWithMessage> chats;

}


