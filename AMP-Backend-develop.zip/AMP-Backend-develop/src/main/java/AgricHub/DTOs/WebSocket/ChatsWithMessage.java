package AgricHub.DTOs.WebSocket;

import AgricHub.Models.Chat.Message;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Builder
public class ChatsWithMessage {

    private UUID id;
    private String userId;
    private String recipientId;
    private List<Message> messages;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime deletedAt;

}
