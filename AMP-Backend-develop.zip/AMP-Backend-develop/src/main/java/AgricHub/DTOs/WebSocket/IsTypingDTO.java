package AgricHub.DTOs.WebSocket;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IsTypingDTO {

    private Boolean isTyping;
    private String userId;
    private String chatId;

}
