package AgricHub.DTOs.UserProfile;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
public class ProfileUpdateDTO {

    private String firstName;
    private String lastName;
    private String phone;
    private String shopName;
    private MultipartFile profileImage;


}
