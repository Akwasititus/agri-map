package AgricHub.Email;

import AgricHub.Models.Token.Token;
import AgricHub.Models.Token.TokenRepository;
import AgricHub.Models.User;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmailTokenService {

    private final TokenRepository tokenRepository;
    private final EmailService emailService;


    @Value("${frontend_url}")
    String frontendBaseUrl;


    public void sendValidationEmail(User user) throws MessagingException {
        var newToken = generateAndSaveActivationToken(user);


        // email properties
        Map<String, Object> properties = new HashMap<>();
        properties.put("username", user.getFirstName());
        properties.put("frontend_url", frontendBaseUrl);
        properties.put("activation_code", newToken);
        properties.put("userEmail", user.getEmail());


        // send email
        emailService.sendEmail(
                user.getEmail(),
                EmailTemplateName.ACTIVATE_ACCOUNT,
                "Welcome to AgricHub Activate Your Account 🌱",
                properties
        );
    }

    private String generateAndSaveActivationToken(User user) {
        String generateToken = generateActivationCode();

        var token = Token.builder()
                .token(generateToken)
                .createdAt(LocalDateTime.now())
                .expiresAt(LocalDateTime.now().plusMinutes(30))
                .user(user)
                .build();

        tokenRepository.save(token);
        return generateToken;
    }

    private String generateActivationCode() {
        String verificationCode = "0123456789";
        StringBuilder codeBuilder = new StringBuilder();
        SecureRandom secureRandom = new SecureRandom();
        for (int i = 0; i < 6; i++) {
            int randomIndex = secureRandom.nextInt(verificationCode.length());
            codeBuilder.append(verificationCode.charAt(randomIndex));
        }
        return codeBuilder.toString();
    }

        public void sendResetPasswordEmail(Optional<User> user, String resetPasswordUrl) throws MessagingException {

        // email properties
        Map<String, Object> properties = new HashMap<>();
            assert user != null;
            properties.put("username", user.get().getFirstName());
        properties.put("resetUrl", resetPasswordUrl);
        properties.put("userEmail", user.get().getEmail());

        // send email
        emailService.sendEmail(
                user.get().getEmail(),
                EmailTemplateName.FORGOT_PASSWORD,
                "Reset Your Password",
                properties
        );
    }
}
