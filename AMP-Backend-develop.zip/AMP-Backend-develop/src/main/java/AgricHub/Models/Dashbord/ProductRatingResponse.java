package AgricHub.Models.Dashbord;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ProductRatingResponse {

    private String username;
    private String userProfile;
    private double averageRate;
    private double rate;
    private String comment;

    private LocalDateTime ratedAt;
}
