
package AgricHub.Models.Dashbord;

public enum PaymentStatus {
    PAID,
    PENDING,
    FAILED
}
