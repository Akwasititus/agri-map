package AgricHub.Models.Dashbord;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Entity;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity(name =  "Cart")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID cartId;
    private  String userEmail;
    private double price;
    private int productCount;

    @ManyToMany()
    private List<Product> products;

    public double calculateTotalPrice() {
        double totalPrice = 0.00;
        for (Product product : products) {
            totalPrice += product.getAmount();
        }
        return totalPrice;
    }

    public void updateTotalPrice() {
        this.price = calculateTotalPrice();
    }

    public int getProductCount() {
        return products.size();
    }
}
