package AgricHub.Models.Dashbord;

public enum Status {
    NEW,
    PROCESSING,
    COMPLETED,
    CANCELLED
}

