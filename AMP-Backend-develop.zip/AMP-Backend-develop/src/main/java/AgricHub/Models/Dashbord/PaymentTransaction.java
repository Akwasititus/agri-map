package AgricHub.Models.Dashbord;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
public class PaymentTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;


    private UUID buyerId;


    private double amount;


    private String email;

    private String userName;
    private String phoneNumbers;

    private UUID productId;
    private String productName;


    private String transactionId;


    private LocalDateTime createdAt;


    private LocalDateTime updatedAt;
}

