package AgricHub.Models.Dashbord;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Builder
public class OrderProductResponseDTO {
    private UUID id;
    private String productId;
    private UUID userId;
    private String username;
    private String location;
    private List<Cart> cartItems;
    private Status status;
    private Integer quantity;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime deletedAt;
}
