package AgricHub.Models.Dashbord;

public enum NotificationType {

    ACTIVE,
    INACTIVE,
    NEW_MESSAGE,
    ORDER_STATUS,
    STOCK_ALERT,
    NEW_ORDER,
    NEW_CHAT

}
