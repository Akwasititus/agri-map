package AgricHub.Models.Dashbord;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Column;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Enumerated;
import jakarta.persistence.EnumType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;
import org.springframework.data.annotation.CreatedDate;

import java.time.LocalDateTime;
import java.util.UUID;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity(name =  "OrderTacking")
public class OrderTracking {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    private String orderID;

    private Status status;



    @Enumerated(EnumType.STRING)
    private Status approved;

    @Enumerated(EnumType.STRING)
    private Status pickedUp;

    @Enumerated(EnumType.STRING)
    private Status shipping;

    @Enumerated(EnumType.STRING)
    private Status delivered;

    @Enumerated(EnumType.STRING)
    private Status payment;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private LocalDateTime orderDate;



}
