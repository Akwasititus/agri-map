package AgricHub.Models.BusinessProfile;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.GenerationType;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.NoArgsConstructor;
import lombok.Builder;

import java.util.UUID;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Entity(name =  "FarmerBusinessProfile")
public class FarmerBusinessProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID businessID;

    @Column(nullable = false)
    private String businessName;

    @Column(nullable = false)
    private String businessEmail;

    @Column(nullable = false)
    private String businessContact;

    @Column(nullable = false)
    private String businessWebsiteUrl;

    @ElementCollection
    @CollectionTable(name = "business_social_mediaLinks", joinColumns = @JoinColumn(name = "business_id"))
    private List<String> businessSocialMediaLinks;


    @Column(nullable = false)
    private String businessCityLocation;

    @Column(nullable = false)
    private String businessCountryLocation;

    @Column(nullable = false)
    private String businessRegionLocation;

    @Column(columnDefinition = "TEXT", length = 1000)
    private String aboutUs;

    @Column(nullable = false)
    private String businessLogo;


    @ElementCollection
    @CollectionTable(name = "business_gallery", joinColumns = @JoinColumn(name = "business_id"))
    @Column(name = "gallery_url", nullable = false)
    private List<String> businessGallery;

    @Column(columnDefinition = "TEXT", length = 1000, nullable = false)
    private String businessVision;

    @Column(columnDefinition = "TEXT", length = 1000, nullable = false)
    private String businessMission;

    @ElementCollection
    @CollectionTable(name = "business_products_produced", joinColumns = @JoinColumn(name = "business_id"))
    @Column(nullable = false)
    private List<String> businessProductsProduced;

    @ElementCollection
    @CollectionTable(name = "business_farming_practice", joinColumns = @JoinColumn(name = "business_id"))
    @Column(nullable = false)
    private List<String> businessFarmingPractice;
}
