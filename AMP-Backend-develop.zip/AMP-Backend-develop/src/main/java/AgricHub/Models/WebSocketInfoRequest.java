package AgricHub.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WebSocketInfoRequest {
    private long entropy;
    private String[] origins;
    private boolean cookieNeeded;
    private boolean websocket;
}
