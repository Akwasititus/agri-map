package AgricHub.Models.Roles;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Permissions {



        // farmer
    FARMER_PROFILE_MANAGEMENT("farmer:view and update profile"),
    FARMER_CREATE("farmer:create product"),
    FARMER_EDIT("farmer:edit product"),
    FARMER_DELETE("farmer:delete product"),
    FARMER_INVENTORY_MANAGEMENT("farmer:manage stocks inventories"),

    FARMER_COUNT_NEW_ORDERS("farmer:count new orders"),
    FARMER_COUNT_COMPLETED_ORDERS("farmer:count completed orders"),
    FARMER_COUNT_ALL_ORDERS("farmer:count all orders"),

    // farmer update order status
    FARMER_UPDATE_ORDER_STATUS("farmer:update order status"),

    FARMER_ORDER_MANAGEMENT("farmer:view orders"),

    FARMER_PRODUCT_SEARCH("farmer:search product"),
    FARMER_PRODUCT_FILTERING("farmer:filter product"),






        // buyer
    BUYER_PROFILE_MANAGEMENT("buyer:view and update profile"),
    BUYER_PRODUCT_SEARCH("buyer:search product"),
    BUYER_PRODUCT_FILTERING("buyer:filter product"),
    BUYER_ADD_PRODUCT_TO_CART("buyer:add product to cart"),
    BUYER_PLACE_ORDER("buyer:place order"),
    BUYER_PAYMENT("buyer:pay for order"),

    BUYER_VIEW_ORDER("buyer:view orders created"),
    BUYER_DELETE_PRODUCTS("buyer:delete product"),
    BUYER_VIEW_PRODUCTS("buyer:view product in cart"),
    BUYER_CANCEL_ORDER("buyer:cancel order"),

    BUYER_COUNT_NEW_ORDERS("buyer:count new orders"),
    BUYER_COUNT_COMPLETED_ORDERS("buyer:count completed orders"),
    BUYER_COUNT_ALL_ORDERS("buyer:count all orders");


    private final String permission;
}
