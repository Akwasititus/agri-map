package AgricHub.Models.Roles;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import static AgricHub.Models.Roles.Permissions.BUYER_PROFILE_MANAGEMENT;
import static AgricHub.Models.Roles.Permissions.BUYER_CANCEL_ORDER;
import static AgricHub.Models.Roles.Permissions.BUYER_ADD_PRODUCT_TO_CART;
import static AgricHub.Models.Roles.Permissions.FARMER_UPDATE_ORDER_STATUS;
import static AgricHub.Models.Roles.Permissions.FARMER_PRODUCT_SEARCH;
import static AgricHub.Models.Roles.Permissions.FARMER_PRODUCT_FILTERING;
import static AgricHub.Models.Roles.Permissions.FARMER_EDIT;
import static AgricHub.Models.Roles.Permissions.FARMER_DELETE;
import static AgricHub.Models.Roles.Permissions.FARMER_COUNT_NEW_ORDERS;
import static AgricHub.Models.Roles.Permissions.FARMER_CREATE;
import static AgricHub.Models.Roles.Permissions.BUYER_PLACE_ORDER;
import static AgricHub.Models.Roles.Permissions.BUYER_PRODUCT_SEARCH;
import static AgricHub.Models.Roles.Permissions.BUYER_PRODUCT_FILTERING;
import static AgricHub.Models.Roles.Permissions.BUYER_PAYMENT;
import static AgricHub.Models.Roles.Permissions.BUYER_VIEW_ORDER;
import static AgricHub.Models.Roles.Permissions.BUYER_DELETE_PRODUCTS;
import static AgricHub.Models.Roles.Permissions.BUYER_VIEW_PRODUCTS;
import static AgricHub.Models.Roles.Permissions.BUYER_COUNT_NEW_ORDERS;
import static AgricHub.Models.Roles.Permissions.BUYER_COUNT_COMPLETED_ORDERS;
import static AgricHub.Models.Roles.Permissions.BUYER_COUNT_ALL_ORDERS;
import static AgricHub.Models.Roles.Permissions.FARMER_PROFILE_MANAGEMENT;
import static AgricHub.Models.Roles.Permissions.FARMER_INVENTORY_MANAGEMENT;
import static AgricHub.Models.Roles.Permissions.FARMER_ORDER_MANAGEMENT;
import static AgricHub.Models.Roles.Permissions.FARMER_COUNT_COMPLETED_ORDERS;
import static AgricHub.Models.Roles.Permissions.FARMER_COUNT_ALL_ORDERS;

@Getter
@RequiredArgsConstructor
public enum RoleEnum {

    //BUYER ROLE
    BUYER(
            Set.of(
                    BUYER_PROFILE_MANAGEMENT,
                    BUYER_PRODUCT_SEARCH,
                    BUYER_PRODUCT_FILTERING,
                    BUYER_ADD_PRODUCT_TO_CART,
                    BUYER_PLACE_ORDER,
                    BUYER_PAYMENT,

                    BUYER_VIEW_ORDER,
                    BUYER_DELETE_PRODUCTS,
                    BUYER_VIEW_PRODUCTS,

                    BUYER_CANCEL_ORDER,


                    BUYER_COUNT_NEW_ORDERS,
                    BUYER_COUNT_COMPLETED_ORDERS,
                    BUYER_COUNT_ALL_ORDERS

            )
    ),
    //FARMER ROLE
    FARMER(
            Set.of(
                    FARMER_PROFILE_MANAGEMENT,
                    FARMER_CREATE,
                    FARMER_EDIT,
                    FARMER_DELETE,
                    FARMER_INVENTORY_MANAGEMENT,

                    FARMER_ORDER_MANAGEMENT,

                    FARMER_COUNT_NEW_ORDERS,
                    FARMER_COUNT_COMPLETED_ORDERS,
                    FARMER_COUNT_ALL_ORDERS,

                    FARMER_UPDATE_ORDER_STATUS,

                    FARMER_PRODUCT_FILTERING,
                    FARMER_PRODUCT_SEARCH


            )
    );

    private final Set<Permissions> permissions;

    public List<SimpleGrantedAuthority> getAuthorities() {
        var authorities = getPermissions()
                .stream()
                .map(permission -> new SimpleGrantedAuthority(permission.getPermission()))
                .collect(Collectors.toList());
        authorities.add(new SimpleGrantedAuthority("ROLE_" + this.name()));
        return authorities;

    }


}
