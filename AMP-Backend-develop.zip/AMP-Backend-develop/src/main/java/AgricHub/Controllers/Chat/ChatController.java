package AgricHub.Controllers.Chat;

import AgricHub.DTOs.ResponseDTOs.AllUnseenNotificationResponse;
import AgricHub.Models.Chat.Chat;
import AgricHub.Models.Chat.Message;
import AgricHub.Services.UserServiceImpl.SocketService.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/chat")
public class ChatController {

    private final NotificationService notificationService;
    private final ChatService chatService;

    @MessageMapping("private-chat")
    public ResponseEntity<String> chatMessage(Message message) {
        chatService.sendMessageChat(message);
        return ResponseEntity.ok("Message Sent Su");
    }

    @GetMapping("/all-user-notification/")
    public ResponseEntity<AllUnseenNotificationResponse>
    getAllNotifications(@RequestParam(name = "userId") String userId) {
        return ResponseEntity.ok(notificationService.getAllUnseenNotifications(userId));
    }

    // Chat

    @GetMapping("/all-user-chat")
    public ResponseEntity<List<Chat>> getAllUserChat(@RequestParam(name = "userId") String userId) {
        return ResponseEntity.ok(chatService.getAllUserChats(userId));
    }

    // Messages

    @GetMapping("/user-messages/")
    public ResponseEntity<List<Message>> getAllUserMessages(@RequestParam(name = "chatId") String chatId) {
        return  ResponseEntity.ok(chatService.getAllUserMessages(chatId));
    }

}
