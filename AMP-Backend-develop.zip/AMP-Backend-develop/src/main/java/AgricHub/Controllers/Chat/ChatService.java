package AgricHub.Controllers.Chat;

import AgricHub.DTOs.WebSocket.ChatsWithMessage;
import AgricHub.DTOs.WebSocket.IsTypingDTO;
import AgricHub.Models.Chat.Chat;
import AgricHub.Models.Chat.Message;
import AgricHub.Models.Dashbord.Notification;
import AgricHub.Models.Dashbord.NotificationType;
import AgricHub.Models.Dashbord.WebSocketHandshake;
import AgricHub.Models.User;
import AgricHub.Repositories.ChatRepository;
import AgricHub.Repositories.MessageRepository;
import AgricHub.Repositories.UserRepository;
import AgricHub.Repositories.WebSocketHandshakeRepository;
import AgricHub.Services.UserServiceImpl.SocketService.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.Optional;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ChatService {

    private final SimpMessagingTemplate messagingTemplate;
    private final WebSocketHandshakeRepository webSocketHandshakeRepository;
    private final ChatRepository chatRepository;
    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    private final NotificationService notificationService;


    public void sendMessageChat(Message message) throws RuntimeException {
        WebSocketHandshake userSocketId = webSocketHandshakeRepository.findByUserId(message.getRecipientId());
        WebSocketHandshake senderSocketId = webSocketHandshakeRepository.findByUserId(message.getUserId());

        boolean chat = chatRepository.existsByUserId(message.getUserId());
        boolean isFromSenderChat = chatRepository.
                existsByUserIdAndRecipientId(message.getUserId(), message.getRecipientId());
        boolean isFromRecipientChat = chatRepository.
                existsByUserIdAndRecipientId(message.getRecipientId(), message.getUserId());
        Chat isChat = chatRepository.
                findByUserIdAndRecipientId(message.getUserId(), message.getRecipientId());
        Chat isChatRecipient = chatRepository.
                findByUserIdAndRecipientId(message.getRecipientId(), message.getUserId());

        Chat newChat = null;
        if ((isFromSenderChat || isFromRecipientChat) && userSocketId != null) {
            if (isChat != null) {
                message.setChatId(String.valueOf(isChat.getId()));
            }
            if (isChatRecipient != null) {
                message.setChatId(String.valueOf(isChatRecipient.getId()));
            }
            messageRepository.save(message);
        } else if (message.getChatId().isEmpty()) {
          newChat =  chatRepository.save(
                    Chat
                    .builder()
                            .recipientId(message.getRecipientId())
                            .userId(message.getUserId())
                            .createdAt(LocalDateTime.now())
                    .build());
            message.setChatId(newChat.getId().toString());
            message.setCreatedAt(LocalDateTime.now());
            messageRepository.save(message);
        }

        Optional<User> user = userRepository.findById(UUID.fromString(message.getUserId()));

        notificationService.sendNotification(message.getRecipientId(), Notification
                .builder()
                        .notificationType(NotificationType.NEW_CHAT)
                        .title("New Message from " + user.get().getFirstName() + " " + user.get().getLastName())
                        .seen(false)
                        .description(message.getMessage())
                        .createdAt(LocalDateTime.now())
                .build());
        messagingTemplate.convertAndSendToUser(userSocketId.getSocketId(), "/queue/private-chats", message);
        messagingTemplate.convertAndSendToUser(userSocketId.getSocketId(), "/queue/private-chats",
                messageRepository.findAllByChatId(message.getChatId()));
        messagingTemplate.convertAndSendToUser(senderSocketId.getSocketId(),
                "/queue/private-chats", messageRepository.findAllByChatId(message.getChatId()));
        getAllUserChatsSocket(message.getRecipientId());
        getAllUserChatsSocket(message.getUserId());
    }

    public List<Chat> getAllUserChats(String userId) {
        List<Chat> invitedChats = chatRepository.findAllByRecipientId(userId);
        List<Chat> createdChats = chatRepository.findAllByUserId(userId);

        List<Chat> allChats = new ArrayList<>();
        allChats.addAll(invitedChats);
        allChats.addAll(createdChats);

        allChats.sort(Comparator.comparing(Chat::getCreatedAt).reversed());

        return allChats;
    }

    public void getAllUserChatsSocket(String userId) {
        // Fetch chats
        List<Chat> invitedChats = chatRepository.findAllByRecipientId(userId);
        List<Chat> createdChats = chatRepository.findAllByUserId(userId);

        // Combine and sort chats
        List<Chat> allChats = new ArrayList<>();
        allChats.addAll(invitedChats);
        allChats.addAll(createdChats);
        allChats.sort(Comparator.comparing(Chat::getCreatedAt).reversed());

        // Fetch WebSocket ID
        WebSocketHandshake userSocketId = webSocketHandshakeRepository.findByUserId(userId);

        // Build the list of ChatsWithMessage
        List<ChatsWithMessage> chatsWithMessages = allChats.stream()
                .map(chat -> {
                    List<Message> messages = messageRepository.findAllByChatId(String.valueOf(chat.getId()));
                    return ChatsWithMessage.builder()
                            .id(chat.getId())
                            .userId(chat.getUserId())
                            .recipientId(chat.getRecipientId())
                            .messages(messages)
                            .createdAt(chat.getCreatedAt())
                            .updatedAt(chat.getUpdatedAt())
                            .deletedAt(chat.getDeletedAt())
                            .build();
                })
                .collect(Collectors.toList());

        // Send to WebSocket
        messagingTemplate.convertAndSendToUser(userSocketId.getSocketId(), "/queue/all-chats", chatsWithMessages);
    }

    public List<Message> getAllUserMessages(String chatId) {
        return messageRepository.findAllByChatId(chatId);
    }

    public void isTyping(IsTypingDTO isTyping) {
        WebSocketHandshake userSocketId = webSocketHandshakeRepository.findByUserId(isTyping.getUserId());
        messagingTemplate.convertAndSendToUser(userSocketId.getSocketId(), "/queue/is-typing", isTyping);
        messagingTemplate.convertAndSendToUser(isTyping.getChatId(), "/queue/is-typing", isTyping);
    }

    public void messageIsSeen(List<Message> messages) {
        for (Message message : messages) {
            message.setSeen(true);
            messageRepository.save(message);
        }
    }
}
