package AgricHub.Controllers;

import AgricHub.Controllers.Chat.ChatService;
import AgricHub.DTOs.WebSocket.IsTypingDTO;
import AgricHub.DTOs.WebSocket.UserOnline;
import AgricHub.Models.Chat.Message;
import AgricHub.Repositories.ConnectionIdRepository;
import AgricHub.Services.UserServiceImpl.SocketService.NotificationService;
import com.amazonaws.services.connect.model.ChatMessage;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import java.security.Principal;
import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin
@RequestMapping("/api/v1/ws")
public class WebSocketController {

    private static final Logger LOG = LoggerFactory.getLogger(WebSocketController.class);
    private final SimpMessagingTemplate messagingTemplate;
    private final ConnectionIdRepository notificationRepository;
    private final NotificationService notificationService;
    private final ChatService chatService;

    @MessageMapping("/message")
    @SendTo("/topic/sellers")
    public ChatMessage broadcastSellers(@Payload ChatMessage chatMessage) {
        return chatMessage;
    }

    @MessageMapping("/private-chats")
    public void sendPrivateUserMessages(
            @Payload Message chatMessage,
            Principal principal
    ) {
        chatService.sendMessageChat(chatMessage);
    }

    @MessageMapping("/all-chats")
    public void sendAllChats(
            @Payload IsTypingDTO userId,
            Principal principal
    ) {
        chatService.getAllUserChatsSocket(userId.getUserId());
    }

    @MessageMapping("/private-chats-seen")
    public void sendPrivateSeenMessages(
            @Payload List<Message> chatMessage,
            Principal principal
    ) {
        chatService.messageIsSeen(chatMessage);
    }

    @MessageMapping("/typing")
    public void isTying(
            @Payload IsTypingDTO isTyping,
            Principal principal
    ) {
        chatService.isTyping(isTyping);
    }

    @MessageMapping("/online")
    @SendTo("/topic/online")
    public UserOnline liveStatus(
            @Payload UserOnline isOnline,
            Principal principal
    ) {
        return isOnline;
    }

    @GetMapping("/")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Works");
    }

    // Chat Controller
}
