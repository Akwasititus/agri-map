package AgricHub.Controllers.Dashboard;

import AgricHub.DTOs.FarmerDTOs.ProductUpdateDTOWithoutImage;
import AgricHub.DTOs.FarmerDTOs.ProductsDTO;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.ProductResponse;
import AgricHub.DTOs.ResponseDTOs.ProductSearchResults;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Models.Dashbord.ProductRatingResponse;
import AgricHub.Services.UserServiceImpl.ProductServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ModelAttribute;


import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/farmer")
public class ProductController {

    private final ProductServiceImpl productService;

    @PostMapping("/add-product")
    public ResponseEntity<GenResponse> addProduct(@ModelAttribute ProductsDTO product) throws IOException {
        return ResponseEntity.ok(productService.addProduct(product));
    }

    @GetMapping("/all")
    public ResponseEntity<List<ProductResponse>> getAllProducts() {
        List<ProductResponse> productResponses = productService.getAllProducts();
        return ResponseEntity.ok(productResponses);
    }

    @GetMapping("/products/{userId}")
    public ResponseEntity<List<Product>> getAFarmersProducts(@PathVariable String userId) {
        return ResponseEntity.ok(productService.getAFarmersProducts(userId));
    }

    @PutMapping("/product/{id}")
    public ResponseEntity<GenResponse> updateProduct(@PathVariable String id, @ModelAttribute ProductsDTO product)
            throws IOException {
        return new ResponseEntity<>(productService.updateProduct(id, product), HttpStatus.OK);
    }

    @PutMapping("/product-without-image/{id}")
    public ResponseEntity<GenResponse> updateAProductWithoutImage(@PathVariable String id,
                                                                  @ModelAttribute ProductUpdateDTOWithoutImage product)
            throws IOException {
        return new ResponseEntity<>(productService.updateAProduct(id, product), HttpStatus.OK);
    }

    @GetMapping("/search")
    public ResponseEntity<ProductSearchResults> searchProducts(@RequestParam(name = "productName") String productName) {
        return ResponseEntity.ok(ProductSearchResults
                .builder()
                .message("Your request for " + "'" + productName + "'")
                .length(productService.search(productName).size())
                .results(productService.search(productName))
                .build());
    }

    @DeleteMapping("/product/{id}")
    public ResponseEntity<GenResponse> deleteProduct(@PathVariable String id) {
        return new ResponseEntity<>(productService.deleteProduct(id), HttpStatus.OK);
    }


    @PostMapping("/rate-product")
    public ResponseEntity<GenResponse> rateProduct(@RequestParam UUID productId,
                                                   @RequestParam UUID userId,
                                                   @RequestParam String comment,
                                                   @RequestParam double rate) {
        return ResponseEntity.ok(productService.rateProduct(userId, productId, rate, comment));
    }


    @GetMapping("/get-product-ratings/{productId}")
    public ResponseEntity<List<ProductRatingResponse>> getRatingsForProduct(@PathVariable UUID productId) {
        List<ProductRatingResponse> ratings = productService.getAllRatings(productId);
        return ResponseEntity.ok(ratings);
    }
}
