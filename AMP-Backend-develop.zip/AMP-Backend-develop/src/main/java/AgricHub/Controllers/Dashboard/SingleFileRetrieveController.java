package AgricHub.Controllers.Dashboard;

import AgricHub.Services.UserServiceImpl.SingleFileUploadService;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;


@RestController
@RequiredArgsConstructor
@RequestMapping("/file")
public class SingleFileRetrieveController {

    private final SingleFileUploadService singleFileUploadService;

    @GetMapping("/{id}/image")
    public ResponseEntity<Resource> getProductImage(@PathVariable String id) {
        try {
            Resource resource = singleFileUploadService.loadImageAsResource(id);
            return ResponseEntity.ok(resource);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}
