package AgricHub.Controllers.Dashboard;

import AgricHub.DTOs.Payment.PaymentRequest;
import AgricHub.DTOs.ResponseDTOs.InitializationResponse.InitializeTransactionResponse;
import AgricHub.DTOs.ResponseDTOs.RecommendedProductResponse;
import AgricHub.DTOs.ResponseDTOs.VerifyTransactionResponse;
import AgricHub.DTOs.ResponseDTOs.WebhookPaymentResponse.WebhookPaymentSuccessResponse;
import AgricHub.Models.Dashbord.Product;
import AgricHub.Services.UserServiceImpl.PaymentIMPL;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/payment")

public class PaymentController {

    private final PaymentIMPL paymentService;



    @PostMapping(path = "/initialize-transaction")
    InitializeTransactionResponse initializeTransaction(@RequestBody PaymentRequest paymentRequest) {
        return paymentService.initializeTransaction(paymentRequest);
    }

    @GetMapping(path = "/verify-transaction/{reference}")
    VerifyTransactionResponse verifyTransaction(@PathVariable String reference) {
        return paymentService.verifyTransaction(reference);
    }

    @PostMapping("/webhook")
    public ResponseEntity<String> handlePaystackWebhook(
            @RequestBody WebhookPaymentSuccessResponse payload
            ) {
        try {
            paymentService.processWebhook(payload);
            return ResponseEntity.ok("Webhook processed successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error processing webhook: " + e.getMessage());
        }
    }

    @GetMapping("/recommended-products/{userId}")
    public ResponseEntity<List<RecommendedProductResponse>> getRecommendedProducts(
            @PathVariable UUID userId,
            @RequestParam(defaultValue = "5") int limit) {
        List<Product> recommendedProducts = paymentService.getMostBoughtProducts(limit, userId);
        List<RecommendedProductResponse> response = recommendedProducts.stream()
                .map(product -> new RecommendedProductResponse(product.getName(), product.getAmount()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(response);
    }

}
