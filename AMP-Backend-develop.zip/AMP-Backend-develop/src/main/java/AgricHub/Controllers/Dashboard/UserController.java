package AgricHub.Controllers.Dashboard;

import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.ShopResponse;
import AgricHub.DTOs.ResponseDTOs.UserResponseRequest;
import AgricHub.Services.UserInterface.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.List;
import java.util.UUID;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/user")
public class UserController {


    private final UserService userService;

    @GetMapping("/{userId}")
    public ResponseEntity<UserResponseRequest> getUserDetails(@PathVariable UUID userId) {
        UserResponseRequest userResponse = userService.getUserDetails(userId);
        return new ResponseEntity<>(userResponse, HttpStatus.OK);
    }

    @GetMapping("/getAllSellers")
    public ResponseEntity<List<ShopResponse>> getAllSellers() {
        List<ShopResponse> farmers = userService.getAllSellers();
        return ResponseEntity.ok(farmers);
    }



    @PostMapping("/rate")
    public ResponseEntity<GenResponse> rateShop(@RequestParam UUID sellerId,
                                                @RequestParam UUID buyerId,
                                                @RequestParam String comment,
                                                @RequestParam double rate) {
        return ResponseEntity.ok(userService.rateShop(sellerId, buyerId, rate, comment));
    }
}
