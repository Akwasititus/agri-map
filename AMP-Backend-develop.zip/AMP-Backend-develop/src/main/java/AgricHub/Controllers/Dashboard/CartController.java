package AgricHub.Controllers.Dashboard;


import AgricHub.DTOs.FarmerDTOs.AddToCartRequest;
import AgricHub.DTOs.FarmerDTOs.UpdateCartItemRequest;
import AgricHub.DTOs.ResponseDTOs.CartProductsResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Services.UserInterface.CartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.UUID;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/buyer/cart")
@PreAuthorize("hasAnyRole('BUYER','FARMER')")
public class CartController {


    private final CartService cartService;


    @PostMapping("/add-products")
    public ResponseEntity<GenResponse> addProductToCart(@RequestBody AddToCartRequest request) {
        GenResponse response = cartService.addProductToCart(request.getUserId(), request.getProductId());
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }


    @DeleteMapping("/remove-products")
    public ResponseEntity<GenResponse> removeProductFromCart(@RequestParam UUID userId, @RequestParam UUID productId) {
        GenResponse response = cartService.removeProductFromCart(userId, productId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @GetMapping("/view-products")
    public ResponseEntity<CartProductsResponse> getCartProducts(@RequestParam UUID userId) {
        CartProductsResponse response = cartService.getCartProducts(userId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("/update-quantity")
    public ResponseEntity<GenResponse> updateProductQuantity(@RequestBody UpdateCartItemRequest request) {
        GenResponse response = cartService.updateProductQuantity(request);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }

    @DeleteMapping("/clear")
    public ResponseEntity<GenResponse> clearCart(@RequestParam UUID userId) {
        GenResponse response = cartService.clearCart(userId);
        return new ResponseEntity<>(response, HttpStatus.valueOf(response.getStatus()));
    }
}
