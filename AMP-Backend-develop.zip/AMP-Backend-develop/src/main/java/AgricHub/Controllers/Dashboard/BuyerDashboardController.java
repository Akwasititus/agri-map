package AgricHub.Controllers.Dashboard;
import AgricHub.DTOs.CountOrders.CountAllCompletedOrders;
import AgricHub.DTOs.CountOrders.CountAllOrders;
import AgricHub.DTOs.CountOrders.NewOrdersCountDTOs;
import AgricHub.DTOs.ResponseDTOs.OrderResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Exception.NotFoundException;
import AgricHub.Models.Dashbord.OrderProduct;
import AgricHub.Models.Dashbord.Status;
import AgricHub.Models.Roles.RoleEnum;
import AgricHub.Models.User;
import AgricHub.Repositories.UserRepository;
import AgricHub.Services.UserInterface.BuyerDashBordService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/buyer/order")
@PreAuthorize("hasAnyRole('BUYER','FARMER')")
public class BuyerDashboardController {


    private final BuyerDashBordService buyerDashBordService;
    private final UserRepository userRepository;

    // orders
    @PostMapping("/create-order")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<GenResponse> createOrder(@RequestBody OrderProduct orderProduct) {
        return new ResponseEntity<>(buyerDashBordService.createOrder(orderProduct), HttpStatus.CREATED);
    }

    // orders
    @DeleteMapping("/{userID}/{orderID}/remove-order")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<GenResponse> removeOrder(@PathVariable UUID userID, @PathVariable UUID orderID) {
        return new ResponseEntity<>(buyerDashBordService.removeOrder(userID, orderID), HttpStatus.CREATED);
    }

    @GetMapping("/{userID}/all-order")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Page<OrderResponse>> getOrderById(
            @PathVariable UUID userID,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {
        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(buyerDashBordService.getPageableOrderById(userID, pageable));
    }

    @GetMapping("/seller-order")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Page<OrderResponse>> getOrderSeller(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {

        // Get the current authenticated user (farmer)
        User currentUser = getCurrentUser();

        // Ensure the current user is a farmer
        if (!currentUser.getRoleEnum().equals(RoleEnum.FARMER)) {
            throw new AccessDeniedException("Only farmers can access this endpoint");
        }


        Pageable pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(buyerDashBordService.getPageableOrdersForSeller(currentUser.getId(), pageable));
    }




    @GetMapping("/all-farmers-orders")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Page<OrderResponse>> getFarmerOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size) {

        // Get the current authenticated user (farmer)
        User currentUser = getCurrentUser();

        // Ensure the current user is a farmer
        if (!currentUser.getRoleEnum().equals(RoleEnum.FARMER)) {
            throw new AccessDeniedException("Only farmers can access this endpoint");
        }

        Pageable pageable = PageRequest.of(page, size);

        return ResponseEntity.ok(buyerDashBordService.getFarmerOrders(currentUser.getId(), pageable));
    }

    //    search query
    @GetMapping("/search")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<OrderProduct>> searchOrdersByUsername(@RequestParam String username) {
        List<OrderProduct> orders = buyerDashBordService.searchOrdersByUsername(username);
        return ResponseEntity.ok(orders);
    }

    @GetMapping("/{farmerId}/filter")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<OrderProduct>> getOrderProductByStatus(@PathVariable UUID farmerId,
                                                                      @RequestParam Status status) {
        List<OrderProduct> products = buyerDashBordService.getOrderProductByStatus(farmerId, status);
        return ResponseEntity.ok(products);
    }


    // changing statuses

    @PutMapping("/{orderId}/status")
    public ResponseEntity<GenResponse> updateOrderStatus(@PathVariable UUID orderId, @RequestParam Status status) {
        GenResponse response = buyerDashBordService.updateOrderStatus(orderId, status);
        return ResponseEntity.status(response.getStatus()).body(response);
    }

    // counting new orders
    @GetMapping("/{userId}/new/order-count")

    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<NewOrdersCountDTOs> getNewOrdersCount(@PathVariable UUID userId) {
        NewOrdersCountDTOs metrics = buyerDashBordService.getNewOrdersCount(userId);
        return ResponseEntity.ok(metrics);
    }

    @GetMapping("/{userId}/all/order-count")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<CountAllOrders> countAllOrders(@PathVariable UUID userId) {
        CountAllOrders metrics = buyerDashBordService.countAllOrders(userId);
        return ResponseEntity.ok(metrics);
    }

    @GetMapping("/{userId}/completed/order-count")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<CountAllCompletedOrders> countAllCompletedOrders(@PathVariable UUID userId) {
        CountAllCompletedOrders metrics = buyerDashBordService.countAllCompletedOrders(userId);
        return ResponseEntity.ok(metrics);
    }


    public User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        return userRepository.findByEmail(username)
                .orElseThrow(() -> new NotFoundException("User not found"));
    }

}
