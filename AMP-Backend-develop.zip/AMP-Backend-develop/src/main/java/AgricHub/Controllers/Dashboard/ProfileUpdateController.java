package AgricHub.Controllers.Dashboard;

import AgricHub.DTOs.ResponseDTOs.ProfileUpdateResponse;
import AgricHub.DTOs.UserProfile.ProfileUpdateDTO;
import AgricHub.Services.UserInterface.ProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestPart;

import java.util.UUID;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/profile")
@PreAuthorize("hasAnyRole('BUYER','FARMER')")
public class ProfileUpdateController {

    private final ProfileService profileService;


        @PutMapping("/{userId}")
        public ResponseEntity<ProfileUpdateResponse> updateUserProfile(@PathVariable UUID userId,
                                                                       @ModelAttribute @RequestPart(required = false)
                                                                       ProfileUpdateDTO profileUpdateDTO,
                                                                      @RequestPart(value = "file", required = false)
                                                                     MultipartFile file) {
            ProfileUpdateResponse response = profileService.updateUserProfile(userId, profileUpdateDTO, file);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }





}
