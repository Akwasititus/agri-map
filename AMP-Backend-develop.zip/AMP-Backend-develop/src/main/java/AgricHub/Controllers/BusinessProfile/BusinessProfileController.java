package AgricHub.Controllers.BusinessProfile;


import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Models.BusinessProfile.FarmerBusinessProfile;
import AgricHub.Services.UserInterface.FarmerBusinessProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/farmer/profile")
public class BusinessProfileController {


    private final FarmerBusinessProfileService farmerBusinessProfileService;


    @PutMapping("/update/{userId}")
    public ResponseEntity<GenResponse> updateProfile(@PathVariable UUID userId,
                                                     @ModelAttribute @RequestPart(value = "profile", required = false)
                                                     FarmerBusinessProfile updatedProfile,
                                                     @RequestPart(value = "logo", required = false)
                                                         MultipartFile logo,
                                                     @RequestPart(value = "galleryImages", required = false)
                                                         List<MultipartFile> galleryImages) {
        GenResponse response = farmerBusinessProfileService.updateFarmerBusinessProfile(updatedProfile, userId,
                logo, galleryImages);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/view-profile/{businessId}")
    public ResponseEntity<FarmerBusinessProfile> viewFarmerBusinessProfileById(@PathVariable UUID businessId) {
        return ResponseEntity.ok(farmerBusinessProfileService.getFarmerBusinessProfileById(businessId));
    }


}
