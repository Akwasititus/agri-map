package AgricHub.Controllers.Authentication;

import AgricHub.DTOs.Login.LoginDTO;
import AgricHub.DTOs.ResponseDTOs.AuthTokenResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Models.ForgotPasswords;
import AgricHub.Services.UserInterface.AuthService;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;


import java.io.IOException;
import java.io.UnsupportedEncodingException;

@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/auth")
public class AuthController {

private final AuthService authServices;


    @PostMapping("/log-in")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<AuthTokenResponse> authenticationResponseEntity(@RequestBody @Valid LoginDTO loginDTO) {
        return new ResponseEntity<>(authServices.login(loginDTO), HttpStatus.OK);
    }

    @PostMapping("/refreshToken")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Void> registerFarmerRefreshToken(
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse) throws IOException {
        authServices.refreshToken(httpServletRequest, httpServletResponse);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping("/activate-account")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<GenResponse> confirm(@RequestParam("token") String token, @RequestParam("email") String email)
            throws MessagingException {
        return new ResponseEntity<>(authServices.activateAccount(token, email), HttpStatus.OK);
    }


    @GetMapping("/resend-activation-code")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<GenResponse> resendActivationCode(@RequestParam("token") String token, @RequestParam("email")
    String email) {
        return new ResponseEntity<>(authServices.resendActivationCode(token, email), HttpStatus.OK);
    }

    @PostMapping("/forgot-password")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<GenResponse> forgotPassword(@RequestBody ForgotPasswords verificationData)
            throws MessagingException, UnsupportedEncodingException {
        return new ResponseEntity<>(authServices.forgotPassword(verificationData), HttpStatus.OK);
    }

    @PutMapping("/verify-forgot-password")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<GenResponse> verifyForgotPassword(@RequestBody ForgotPasswords forgotBody,
                                                            HttpServletRequest requestObject) {
        return new ResponseEntity<>(authServices.verifyForgotPassword(forgotBody, requestObject), HttpStatus.OK);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
        // Perform any custom logout logic here
        new SecurityContextLogoutHandler().logout(request, response, null);

        return ResponseEntity.ok().body("Logged out successfully");
    }



}
