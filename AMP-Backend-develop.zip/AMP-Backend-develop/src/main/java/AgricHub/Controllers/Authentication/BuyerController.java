package AgricHub.Controllers.Authentication;

import AgricHub.DTOs.BuyerDTOs.BuyerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Services.UserInterface.BuyerAuthServices;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;


@RequiredArgsConstructor
@RestController
@RequestMapping("api/v1/auth")
public class BuyerController {

    private final BuyerAuthServices buyerAuthServices;


    @PostMapping("/register-buyer")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<GenResponse> registerBuyer(@RequestBody @Valid BuyerRegistrationDto buyerRegistrationDto)
            throws MessagingException {
        return new ResponseEntity<>(buyerAuthServices.registerBuyer(buyerRegistrationDto), HttpStatus.CREATED);
    }
}
