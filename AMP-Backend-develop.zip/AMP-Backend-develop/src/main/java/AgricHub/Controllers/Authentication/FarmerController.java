package AgricHub.Controllers.Authentication;

import AgricHub.DTOs.FarmerDTOs.FarmerRegistrationDto;
import AgricHub.DTOs.ResponseDTOs.BanksResponses;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.Services.UserInterface.FarmerAuthServices;
import AgricHub.Services.UserServiceImpl.PaystackService;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;


import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/auth")
public class FarmerController {

    private final FarmerAuthServices authServices;
    private final PaystackService paystackService;


    @PostMapping("/register-farmer")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<GenResponse> registerFarmer(@RequestBody @Valid FarmerRegistrationDto farmerRegistrationDto)
            throws MessagingException {
        return new ResponseEntity<>(authServices.registerFarmer(farmerRegistrationDto), HttpStatus.CREATED);
    }

    @GetMapping("/banks")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<BanksResponses>> createBanks() {
        return new ResponseEntity<>(paystackService.createBanks(), HttpStatus.OK);
    }
}
