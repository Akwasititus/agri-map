package AgricHub.Controllers;

import AgricHub.DTOs.ResponseDTOs.AllUnseenNotificationResponse;
import AgricHub.DTOs.ResponseDTOs.GenResponse;
import AgricHub.DTOs.ResponseDTOs.SuccessWebSocketHandshake;
import AgricHub.Models.Dashbord.Notification;
import AgricHub.Records.WebSocketHSRequest;
import AgricHub.Services.UserServiceImpl.SocketService.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;

@RestController
@RequestMapping("/api/v1/handshake")
@RequiredArgsConstructor
public class NotificationHandshakeController {

    private final NotificationService notificationService;

    // Register Socket Handshake
    @PostMapping("/initiate-socket-handshake")
    public ResponseEntity<SuccessWebSocketHandshake> initiateSocketHandshake(@RequestBody WebSocketHSRequest request) {
        return ResponseEntity.ok(notificationService.initiateHandshake(request));
    }

    @GetMapping("/seen-notification")
    public ResponseEntity<GenResponse> notificationViewed(@RequestBody Notification notification) {
        return ResponseEntity.ok(GenResponse
                .builder()
                .status(HttpStatus.OK.value())
                .message("Notification viewed by user!")
                .build());
    }

    // Get all Unseen Notifications
    @GetMapping("/all-unseen")
    public ResponseEntity<AllUnseenNotificationResponse> getAllUnseenNotifications(
            @RequestParam(name = "userId") String userId
    ) {
        return ResponseEntity.ok(notificationService.getAllUnseenNotifications(userId));
    }
}
